package com.github.standobyte.jojo.client.util.functions;

import java.util.List;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.github.standobyte.jojo.client.ClientTickHandler;
import com.github.standobyte.jojo.client.ui.utils.BlitFloat;
import com.github.standobyte.jojoimpl.stands.theworld.timestop.client.TimeStopClientState;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexSorting;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.TickRateManager;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.client.ClientHooks;

public class ClientUtil {
	public static final int MAX_LIGHT = 0xF000F0;
	public static final int NO_OVERLAY = OverlayTexture.NO_OVERLAY;
	
	public static final float PLAYER_RENDER_SCALE = 0.9375F;
	public static final float DEFAULT_STAND_WIDTH = 0.6f;
	public static final float DEFAULT_STAND_HEIGHT = 1.8f;

	public static void setCameraEntityPreventShaderSwitch(Entity entity) {
		Minecraft mc = Minecraft.getInstance();
		mc.setCameraEntity(entity);
		// TODO prevent shader switch
//		if (mc.gameRenderer.currentEffect() == null) {
//			ShaderEffectApplier.getInstance().updateCurrentShader();
//		}
	}
	
	public static Entity getCameraEntity() {
		Minecraft mc = Minecraft.getInstance();
		return mc.cameraEntity != null ? mc.cameraEntity : mc.player;
	}

	public static float partialTick() {
		return partialTick(Minecraft.getInstance().getTimer(), false);
	}

	public static float partialTick(DeltaTracker deltaTracker, boolean worksInPauseToo) {
		if (worksInPauseToo) {
			return switch (deltaTracker) {
				case DeltaTracker.Timer timer -> timer.deltaTickResidual;
				case DeltaTracker.DefaultValue defaultVal -> defaultVal.getGameTimeDeltaPartialTick(false);
				default -> 0;
			};
		}
		ClientLevel level = Minecraft.getInstance().level;
		TickRateManager tickRateManager = level != null ? level.tickRateManager() : null;
		boolean runsNormally = tickRateManager == null || tickRateManager.runsNormally();
		return deltaTracker.getGameTimeDeltaPartialTick(runsNormally);
	}
	
	public static float partialTick(Entity entity) {
		Minecraft mc = Minecraft.getInstance();
		return partialTick(entity, mc.getTimer(), entity.level().tickRateManager());
	}
	
	public static float partialTick(Entity entity, DeltaTracker deltaTracker, TickRateManager tickRateManager) {
		if (TimeStopClientState.isEntityFrozen(entity)) {
			return TimeStopClientState.partialTick;
		}
		boolean isEntityFrozen = tickRateManager.isEntityFrozen(entity);
		return deltaTracker.getGameTimeDeltaPartialTick(!isEntityFrozen);
	}
	
	public static float getTime(boolean worksInPauseToo) {
		return ClientTickHandler.tickCount + partialTick(Minecraft.getInstance().getTimer(), worksInPauseToo);
	}

	public static int getScreenMouseX() {
		Minecraft mc = Minecraft.getInstance();
		return (int)(
				mc.mouseHandler.xpos()
				* (double)mc.getWindow().getGuiScaledWidth()
				/ (double)mc.getWindow().getScreenWidth());
	}

	public static int getScreenMouseY() {
		Minecraft mc = Minecraft.getInstance();
		return (int)(
				mc.mouseHandler.ypos()
				* (double)mc.getWindow().getGuiScaledHeight()
				/ (double)mc.getWindow().getScreenHeight());
	}

	// it just works
	public static float getHighlightAlpha(float ticks, float cycleTicks, float maxAlphaTicks, float minAlpha, float maxAlpha) {
		ticks %= cycleTicks;
		float coeff = maxAlpha / maxAlphaTicks;
		float alpha = ticks <= cycleTicks / 2 ? coeff * ticks : coeff * (cycleTicks - ticks);
		return Math.min(alpha, maxAlpha - minAlpha) + minAlpha;
	}

	public static void renderEntityFace(PoseStack poseStack, float x, float y, LivingEntity entity) { renderEntityFace(poseStack, x, y, entity, BlitFloat.NO_TINT, true); }
	public static void renderEntityFace(PoseStack poseStack, float x, float y, LivingEntity entity, int color, boolean showOuterLayer) {
		if (entity instanceof AbstractClientPlayer player) {
			renderPlayerFace(poseStack, x, y, player, color, showOuterLayer);
		}
	}

	public static final float OUTER_LAYER_SCALE = 9f/8f;
	public static void renderPlayerFace(PoseStack poseStack, float x, float y, AbstractClientPlayer player) { renderPlayerFace(poseStack, x, y, player, BlitFloat.NO_TINT, true); }
	public static void renderPlayerFace(PoseStack poseStack, float x, float y, AbstractClientPlayer player, int color, boolean showOuterLayer) {
		Minecraft mc = Minecraft.getInstance();
		PlayerSkin playerSkin = player.getSkin();
		ResourceLocation playerFace = playerSkin.texture();
		BlitFloat.blit(poseStack, mc, playerFace, 
				x, y, 16, 16, 0, 
				8, 8, 8, 8, 64, 64, 
				color);
		if (showOuterLayer && player.isModelPartShown(PlayerModelPart.HAT)) {
			poseStack.pushPose();
			poseStack.translate(x + 8, y + 8, 0);
			poseStack.scale(OUTER_LAYER_SCALE, OUTER_LAYER_SCALE, 0);
			poseStack.translate(-x - 8, -y - 8, 0);
			BlitFloat.blit(poseStack, mc, playerFace, 
					x, y, 16, 16, 0, 
					40, 8, 8, 8, 64, 64, 
					color);
			poseStack.popPose();
		}
	}
	
	public static void applyCameraTransform(PoseStack stack){
		Minecraft minecraft = Minecraft.getInstance();
		Camera camera = minecraft.gameRenderer.getMainCamera();
		float partialTick = minecraft.getTimer().getGameTimeDeltaPartialTick(true);
		double d0 = ClientHooks.getFieldOfView(minecraft.gameRenderer, camera, partialTick, minecraft.options.fov().get().doubleValue(), true);
		Matrix4f matrix4f = minecraft.gameRenderer.getProjectionMatrix(d0);
		matrix4f.mul(stack.last().pose());
		float f2 = minecraft.options.screenEffectScale().get().floatValue();
		float f3 = Mth.lerp(partialTick, minecraft.player.oSpinningEffectIntensity, minecraft.player.spinningEffectIntensity) * f2 * f2;
		if (f3 > 0.0F) {
			int i = minecraft.player.hasEffect(MobEffects.CONFUSION) ? 7 : 20;
			float f4 = 5.0F / (f3 * f3 + 5.0F) - f3 * 0.04F;
			f4 *= f4;
			Vector3f vector3f = new Vector3f(0.0F, Mth.SQRT_OF_TWO / 2.0F, Mth.SQRT_OF_TWO / 2.0F);
			float f5 = (partialTick) * (float)i * (float) (Math.PI / 180.0);
			matrix4f.rotate(f5, vector3f);
			matrix4f.scale(1.0F / f4, 1.0F, 1.0F);
			matrix4f.rotate(-f5, vector3f);
		}
		RenderSystem.setProjectionMatrix(matrix4f, VertexSorting.DISTANCE_TO_ORIGIN);
	}

	public static void addItemReferenceQuote(List<Component> tooltip, Item item) {
		ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(item);
		addItemReferenceQuote(tooltip, item, itemId.getNamespace() + "." + itemId.getPath());
	}

	public static void addItemReferenceQuote(List<Component> tooltip, Item item, String itemName) {
		tooltip.add(Component.literal(" "));
		tooltip.add(Component.translatable("item." + itemName + ".reference_quote").withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
	}

	public static Component donoItemTooltip(String donoUsername) {
		return Component.translatable("item.jojo_ripples.dono_tooltip", donoUsername).withStyle(ChatFormatting.DARK_GRAY);
	}
}
