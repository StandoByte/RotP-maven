package com.github.standobyte.jojo.client.ui.hud_power;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.github.standobyte.jojo.client.ClientGlobals;
import com.github.standobyte.jojo.client.ClientPowerCache;
import com.github.standobyte.jojo.client.ClientTickHandler;
import com.github.standobyte.jojo.client.input.InputHandler;
import com.github.standobyte.jojo.client.input.controlscheme.AbilityControlScheme;
import com.github.standobyte.jojo.client.standskin.StandSkin;
import com.github.standobyte.jojo.client.standskin.StandSkinsLoader;
import com.github.standobyte.jojo.client.standskin.text.StandNameSetColor;
import com.github.standobyte.jojo.client.textsymbols.IconSymbols;
import com.github.standobyte.jojo.client.ui.hud_misc.ChangeXpBar;
import com.github.standobyte.jojo.client.ui.hud_power.PowerHudControlsElement.AbilityBindUI;
import com.github.standobyte.jojo.client.ui.hud_power.PowerHudControlsElement.BindUI;
import com.github.standobyte.jojo.client.ui.hud_power.PowerHudControlsElement.HotbarUILine;
import com.github.standobyte.jojo.client.ui.utils.BlitFloat;
import com.github.standobyte.jojo.client.ui.utils.ElementTransparency;
import com.github.standobyte.jojo.client.ui.utils.GuiIcon;
import com.github.standobyte.jojo.client.ui.utils.TextUtil;
import com.github.standobyte.jojo.client.ui.utils.tooltip.MultiLineScreenTooltip;
import com.github.standobyte.jojo.client.util.functions.ClientUtil;
import com.github.standobyte.jojo.config.stand_toggles.ClientStandToggle;
import com.github.standobyte.jojo.config.stand_toggles.ClientStandToggles;
import com.github.standobyte.jojo.core.JojoMod;
import com.github.standobyte.jojo.mechanics.resolve.ResolveCounter;
import com.github.standobyte.jojo.mechanics.resolve.ResolveModeEffect;
import com.github.standobyte.jojo.mechanics.resolve.ResolveStageBuffs;
import com.github.standobyte.jojo.powersystem.Power;
import com.github.standobyte.jojo.powersystem.PowerClass;
import com.github.standobyte.jojo.powersystem.PowerType;
import com.github.standobyte.jojo.powersystem.standpower.StandPower;
import com.github.standobyte.jojo.powersystem.standpower.client_screens.StandSkillsScreen;
import com.github.standobyte.jojo.powersystem.standpower.entity.StandEntity;
import com.github.standobyte.jojo.powersystem.standpower.type.StandTypePersistentData;
import com.github.standobyte.jojo.powersystem.standpower.type.StandTypePersistentData.StandExpSummary;
import com.github.standobyte.jojo.powersystem.standpower.type.SummonedStand;
import com.github.standobyte.jojo.util.functions.MathUtil;
import com.github.standobyte.v1_21_4_stuff.missingmethods.ARGB;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;

import it.unimi.dsi.fastutil.floats.FloatArrayList;
import it.unimi.dsi.fastutil.floats.FloatList;
import net.minecraft.ChatFormatting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.navigation.ScreenPosition;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.util.Mth;
import net.minecraft.util.StringUtil;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ContainerScreenEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.util.TriState;

@EventBusSubscriber(modid = JojoMod.MOD_ID, value = Dist.CLIENT)
public class PowerHud {
	public static AbilityHud abilityHUDInstance;

	@SubscribeEvent
	public static void addHud(RegisterGuiLayersEvent event) {
		event.registerBelow(VanillaGuiLayers.BOSS_OVERLAY, 
				JojoMod.resLoc("ability_hud"), abilityHUDInstance = new AbilityHud());
		event.registerBelowAll(JojoMod.resLoc("ability_hud_pre"), new LayeredDraw.Layer() {
			
			@Override
			public void render(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
				abilityHUDInstance.preRender(guiGraphics, deltaTracker);
			}
		});
	}
	
	
	public static boolean hasElementTooltips(Screen screen) {
		return screen instanceof ChatScreen
				|| /*F3+Esc*/ screen instanceof PauseScreen pause && !pause.showsPauseMenu();
	}
	
	public static boolean canDragElementsOn(Screen screen) {
		return screen instanceof ChatScreen
				|| screen instanceof PauseScreen pause && !pause.showsPauseMenu();
	}
	
	public static boolean isInContainerScreen() {
		return Minecraft.getInstance().screen instanceof AbstractContainerScreen;
	}
	
	@SubscribeEvent
	public static void onContainerMenuRender(ContainerScreenEvent.Render.Foreground event) {
		GuiGraphics graphics = event.getGuiGraphics();
		AbstractContainerScreen<?> screen = event.getContainerScreen();
		graphics.pose().pushPose();
		graphics.pose().translate(-screen.getGuiLeft(), -screen.getGuiTop(), 0.0F);
		abilityHUDInstance.setupRender(TriState.TRUE);
		abilityHUDInstance.renderAbilitiesHUD(graphics, Minecraft.getInstance().getTimer()/*getDeltaTracker()*/);
		graphics.pose().popPose();
	}
	
	@SubscribeEvent
	public static void addDraggableToScreen(ScreenEvent.Init.Post event) {	
		Screen screen = event.getScreen();
		if (canDragElementsOn(screen)) {
			for (HudElement element : abilityHUDInstance.elements.values()) {
				event.addListener(element);
			}
		}
	}
	
	public static boolean canHaveHudOpen() {
		Player player = Minecraft.getInstance().player;
		return player != null && !player.isSpectator();
	}
	
	
	public static class AbilityHud implements LayeredDraw.Layer {
		public Map<String, HudElement> elements = new HashMap<>();
		
		public <T extends HudElement> T addElement(T element) {
			element.hud = this;
			elements.put(element.name, element);
			return element;
		}
		
		public LayeredDraw.Layer beforeAllLayers() {
			return new LayeredDraw.Layer() {

				@Override
				public void render(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
					AbilityHud.this.preRender(guiGraphics, deltaTracker);
				}
			};
		}
		
		
		/** DEFAULT - no container menu screen is currently opened; TRUE - container screen foreground; FALSE - container screen background */
		public TriState forContainerMenu = TriState.DEFAULT;
		private int mouseX;
		private int mouseY;
		
		public void setupRender(TriState forContainerMenu) {
			setupRender(forContainerMenu, -1, -1);
		}
		
		public void setupRender(TriState forContainerMenu, int mouseX, int mouseY) {
			this.forContainerMenu = forContainerMenu;
			this.mouseX = mouseX;
			this.mouseY = mouseY;
		}

	
		public PowerHudControlsElement controls = 	addElement(new PowerHudControlsElement("controls", 4, 44, -1, -1));
		public PowerIcon powerIcon = 			addElement(new PowerIcon("powerIcon", 11, 12, 16, 16));
		public Resolve resolveBar = 			addElement(new Resolve("resolve_bar", 31, 12, 32, 16));
		public RotpXpBarReplacement xpBar = 	addElement(new RotpXpBarReplacement("xp_bar"));
		public Stamina staminaBar = 			addElement(new Stamina("stamina_bar", 81, 16, Bars.HORIZONTAL_LENGTH + 8, Bars.HORIZONTAL_WIDTH));
		public StandRange standRange = 			addElement(new StandRange("stand_range", 
				(int) staminaBar.xOffsetL + staminaBar.getWidth() + 10, (int) staminaBar.yOffsetU, -1, -1));
		public Finisher finisherBar = 			addElement(new Finisher("stand_finisher", 
				HudElement.SnappingH.CENTER, HudElement.SnappingV.CENTER, -16, -16, 32, 32));
		public StandToggles toggles = 			addElement(new StandToggles("stand_toggles", 4, 4, 32, 32));
		
		
		public void preRender(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			if (mc.options.hideGui || !canHaveHudOpen()) return;
			
			int mouseX = -1;
			int mouseY = -1;
			boolean isContainer = mc.screen instanceof AbstractContainerScreen;
			if (!isContainer) {
				if (mc.screen != null && hasElementTooltips(mc.screen)) {
					mouseX = (int)(mc.mouseHandler.xpos()
							* (double)mc.getWindow().getGuiScaledWidth()
							/ (double)mc.getWindow().getScreenWidth());
					mouseY = (int)(mc.mouseHandler.ypos()
							* (double)mc.getWindow().getGuiScaledHeight()
							/ (double)mc.getWindow().getScreenHeight());
				}
			}
			WindupAtCrosshair.setRender(null);
			setupRender(isContainer ? TriState.FALSE : TriState.DEFAULT, mouseX, mouseY);
			
			for (var element : elements.values()) {
				element.preRender(guiGraphics, deltaTracker, mouseX, mouseY);
			}
		}
		
		@Override
		public void render(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			renderAbilitiesHUD(guiGraphics, deltaTracker);
			WindupAtCrosshair.renderCrosshair(guiGraphics, deltaTracker, mc);
		}

		public void renderAbilitiesHUD(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			if (mc.options.hideGui) return;
			
			for (var element : elements.values()) {
				if (element.shouldRender()) {
					RenderSystem.enableBlend();
					RenderSystem.defaultBlendFunc();
					if (mouseX > -1 && mouseY > -1) {
						element.render(guiGraphics, deltaTracker, mouseX, mouseY);
					}
					else {
						element.render(guiGraphics, deltaTracker);
					}
				}
			}
			RenderSystem.disableBlend();
		}
		
		public boolean isAbilitySelected(String abilityName) {
			if (!canHaveHudOpen() || !controls.shouldRender()) return false;
			
			for (BindUI bind : controls.binds) {
				for (AbilityBindUI bindAbility : bind.abilities.values()) {
					if (bindAbility.isOfAbility(abilityName)) {
						return true;
					}
				}
			}
			for (HotbarUILine hotbar : controls.hotbars) {
				if (hotbar.selected != null) {
					for (AbilityBindUI bindAbility : hotbar.selected.abilities.values()) {
						if (bindAbility.isOfAbility(abilityName)) {
							return true;
						}
					}
				}
			}
			return false;
		}
		
	}
	
	
	public static class PowerIcon extends HudElement {
		protected PowerClass<?> powerClass;
		protected boolean standSummoned;

		public PowerIcon(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public PowerIcon(String name, SnappingH snappingHorizontal, SnappingV snappingVertical, 
				int xOffset, int yOffset, int width, int height) {
			super(name, snappingHorizontal, snappingVertical, xOffset, yOffset, width, height);
		}
		
		@Override
		protected void initText() {
			super.initText();
			tooltipText.body.clear();
		}
		
		@Override
		public void preRender(GuiGraphics guiGraphics, DeltaTracker deltaTracker, double mouseX, double mouseY) {
			StandPower standPower = ClientPowerCache.getPower(PowerClass.STAND);
			standSummoned = standPower != null && standPower.isSummoned();
			powerClass = null;
			
			if (!hud.forContainerMenu.isTrue()) {
				var controlScheme = InputHandler.getInstance().getActiveControlScheme();
				if (controlScheme != null) {
					powerClass = controlScheme.powerClassCosmetic;
					if (powerClass == PowerClass.STAND && !standSummoned) {
						powerClass = null;
					}
				}
			}
			
			if (standSummoned) {
				if (powerClass == null) {
					powerClass = PowerClass.STAND;
				}
				else if (powerClass != PowerClass.STAND) {
					standSummoned = false;
				}
			}
		}

		@Override
		public boolean shouldRender() {
			return powerClass != null;
		}

		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			if (powerClass != null) {
				if (powerClass == PowerClass.STAND) {
					float alpha = 1;
					if (ClientGlobals.playerStandEntity != null) {
						StandEntity entity = ClientGlobals.playerStandEntity;
						float partialTick = ClientUtil.partialTick(entity, deltaTracker, entity.level().tickRateManager());
						alpha = ClientGlobals.playerStandEntity.clientStuff.getAlpha(entity, partialTick, true);
					}
					else if (ClientGlobals.playerStand instanceof SummonedStand.SyncableSummonedStand stand) {
						float partialTick = ClientUtil.partialTick(mc.player, deltaTracker, mc.level.tickRateManager());
						alpha = stand.unsummonAlpha(partialTick);
					}
					renderClientStandIcon(guiGraphics.pose(), getX(), getY(), ARGB.white(alpha));
				}
				else {
					Power<?> power = ClientPowerCache.getPower(powerClass);
					if (power != null && power.hasPower()) {
						GuiIcon icon = getPowerIcon(power.getPowerType());
						icon.render(guiGraphics.pose(), getX(), getY());
					}
				}
			}
		}
		
		@Override
		protected void checkTooltip(double mouseX, double mouseY, DeltaTracker deltaTracker) {
			if (standSummoned) {
				Power<?> power = ClientPowerCache.getPower(PowerClass.STAND);
				if (power != null && power.hasPower()) {
					Component powerName = power.getName();
					powerName = StandNameSetColor.fromSkin(power, powerName, true);
					tooltipText.setTitle(Component.translatable("ripples_hud.stand_summoned", powerName.copy())
							.withStyle(ChatFormatting.BLACK));
				}
			}
			else {
				Power<?> power = ClientPowerCache.getPower(powerClass);
				if (power != null && power.hasPower()) {
					Component powerName = power.getName();
					powerName = StandNameSetColor.fromSkin(power, powerName, true);
					tooltipText.setTitle(powerName.copy()
							.withStyle(ChatFormatting.BLACK));
				}
			}
			super.checkTooltip(mouseX, mouseY, deltaTracker);
		}
	}
	
	public static void renderClientStandIcon(PoseStack pose, float x, float y) {
		renderStandIcon(ClientPowerCache.getPower(PowerClass.STAND), pose, x, y, BlitFloat.NO_TINT);
	}
	
	public static void renderClientStandIcon(PoseStack pose, float x, float y, int color) {
		renderStandIcon(ClientPowerCache.getPower(PowerClass.STAND), pose, x, y, color);
	}
	
	public static void renderStandIcon(StandPower standPower, PoseStack pose, float x, float y, int color) {
		if (standPower != null) {
			StandSkin skin = StandSkinsLoader.getInstance().getSkin(standPower);
			if (skin != null) {
				GuiIcon icon = skin.getStandIcon();
				if (icon != null) {
					RenderSystem.enableBlend();
					RenderSystem.defaultBlendFunc();
					icon.render(pose, x, y, color);
					RenderSystem.disableBlend();
				}
			}
		}
	}
	
	protected static final Map<ResourceLocation, GuiIcon> POWER_ICONS = new HashMap<>();
	public static GuiIcon getPowerIcon(PowerType powerType) {
		return POWER_ICONS.computeIfAbsent(powerType.getId(), 
				id -> new GuiIcon(id.withPath(path -> "textures/power/" + path + ".png"), 16, 16));
	}
	public static GuiIcon getPowerIcon(Supplier<? extends PowerType> powerType) { return getPowerIcon(powerType.get()); }
		
		
	public static class Resolve extends HudElement {
		public static final GuiIcon RESOLVE_MODE = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_mode_bar.png"), 40, 40);
		public static final GuiIcon HORIZONTAL_EMPTY = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_horizontal_empty.png"), 32, 16);
		public static final GuiIcon HORIZONTAL_FULL = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_horizontal_full.png"), 32, 16);
		public static final GuiIcon VERTICAL_EMPTY = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_vertical_empty.png"), 16, 32);
		public static final GuiIcon VERTICAL_FULL = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_vertical_full.png"), 16, 32);
		
		public static final GuiIcon STAGE_BAR_HORIZONTAL = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stages_h.png"), 32, 16);
		public static final GuiIcon[] STAGE_HORIZONTAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_1_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_2_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_3_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_4_h.png"), 32, 16)
		};
		public static final GuiIcon[] STAGE_UNLOCKED_HORIZONTAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked1_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked2_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked3_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked4_h.png"), 32, 16)
		};
		public static final GuiIcon STAGE_BAR_VERTICAL = new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stages_v.png"), 16, 32);
		public static final GuiIcon[] STAGE_VERTICAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_1_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_2_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_3_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_4_v.png"), 16, 32)
		};
		public static final GuiIcon[] STAGE_UNLOCKED_VERTICAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked1_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked2_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked3_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_stage_unlocked4_v.png"), 16, 32)
		};
		
		public static final GuiIcon[] LVL_HORIZONTAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_1_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_2_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_3_h.png"), 32, 16),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_4_h.png"), 32, 16)
		};
		public static final GuiIcon[] LVL_VERTICAL = new GuiIcon[] {
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_1_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_2_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_3_v.png"), 16, 32),
				new GuiIcon(JojoMod.resLoc("textures/hud/stand_resolve/stand_resolve_lvl_4_v.png"), 16, 32)
		};

		public Resolve(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public Resolve(String name, SnappingH snappingHorizontal, SnappingV snappingVertical, 
				int xOffset, int yOffset, int width, int height) {
			super(name, snappingHorizontal, snappingVertical, xOffset, yOffset, width, height);
		}
		
		@Override
		protected void initText() {
		}

		@Override
		public boolean shouldRender() {
			if (hud.forContainerMenu == TriState.TRUE) return false;
			ResolveCounter resolve = ResolveCounter.getIfEnabled(Minecraft.getInstance().player);
			if (resolve != null) {
				AbilityControlScheme controlScheme = InputHandler.getInstance().getActiveControlScheme();
				return controlScheme != null && controlScheme.hasAbility(ability -> ability.powerClass() == PowerClass.STAND);
			}
			
			return false;
		}
		
		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			LivingEntity user = mc.player;
			ResolveCounter resolve = ResolveCounter.getIfEnabled(user);
			if (resolve == null) return;
			
			float partialTick = ClientUtil.partialTick(deltaTracker, false);
			
			int width = getWidth();
			int height = getHeight();
			
			GuiIcon emptySprite = HORIZONTAL_EMPTY;
			GuiIcon fullSprite = HORIZONTAL_FULL;
			int spriteWidth = 32;
			int spriteHeight = 16;
			int x = getX() + (width - spriteWidth) / 2;
			int y = getY() + (height - spriteHeight) / 2;

			MobEffectInstance resolveEffect = ResolveModeEffect.maxDurationResolveEffect(user);
			if (resolveEffect != null) {
				// resolve mode timer circle
				int duration = resolveEffect.getDuration();
				int timer = resolve.resolveModeTimer;
				int timerInitial = resolve.resolveModeInitial;
				
				if (timerInitial > -1 && timer > -1) {
					duration = Math.min(timer, duration);
				}
				float value = duration + 1 - partialTick;
				if (value > 0) {
					float resolveModeDurationRatio = timerInitial > 0 ? value / timerInitial : 1;
					BlitFloat.blitRadial(guiGraphics.pose(), mc, RESOLVE_MODE.file, 
							x + (spriteWidth - RESOLVE_MODE.width) / 2, y + (spriteHeight - RESOLVE_MODE.height) / 2, RESOLVE_MODE.width, RESOLVE_MODE.height, 0, 
							0, resolveModeDurationRatio, BlitFloat.NO_TINT);
				}
			}
			
			float lmbRmbFadeIn = 0;
			if (resolveEffect == null && resolve.getCurStage() >= 0) {
				float tick = ClientTickHandler.tickCount + partialTick;
				lmbRmbFadeIn = 2 * Mth.sin(tick * 0.05f) - 0.75f;
				lmbRmbFadeIn = Mth.clamp(lmbRmbFadeIn, 0, 1);
			}
			if (lmbRmbFadeIn < 1) {
				// resolve kanji fill
				float alpha = 1 - lmbRmbFadeIn;
				BlitFloat.blit(guiGraphics.pose(), mc, emptySprite.file, 
						x, y, spriteWidth, spriteHeight, 0, 
						ARGB.white(alpha));
				float resolveRatio = resolve.getResolveBarFill();
				float fillWidth = resolveRatio >= 1 ? spriteWidth : 2 + (spriteWidth - 6) * resolveRatio;
				BlitFloat.blit(guiGraphics.pose(), mc, fullSprite.file, 
						x, y, fillWidth, spriteHeight, 0, 
						0, 0, fillWidth, spriteHeight, spriteWidth, spriteHeight, 
						ARGB.white(alpha));
			}
			if (lmbRmbFadeIn > 0) {
				// LMB + RMB prompt fading in and out
				String resolveActivationPrompt = IconSymbols.LMB_CLICK_LARGE + "+" + IconSymbols.RMB_CLICK_LARGE;
				guiGraphics.drawCenteredString(mc.font, Component.literal(resolveActivationPrompt), 
						x + spriteWidth / 2, y + 4, ARGB.white(TextUtil.fixAlpha(lmbRmbFadeIn)));
				RenderSystem.enableBlend();
				RenderSystem.defaultBlendFunc();
			}
			
			int lvlX = x;
			int lvlY = y + 16;
			if (resolveEffect != null) {
				// resolve mode level
				GuiIcon[] lvlSprites = LVL_HORIZONTAL;
				GuiIcon sprite = lvlSprites[Mth.clamp(resolveEffect.getAmplifier(), 0, lvlSprites.length - 1)];
				sprite.render(guiGraphics.pose(), lvlX, lvlY);
			}
			else {
				GuiIcon sprite;
				GuiIcon[] stageSprites;
				
				// empty bar
				sprite = STAGE_BAR_HORIZONTAL;
				sprite.render(guiGraphics.pose(), lvlX, lvlY);
				
				// unlocked resolve stages
				stageSprites = STAGE_UNLOCKED_HORIZONTAL;
				sprite = stageSprites[Mth.clamp(resolve.getUnlockedStage(), 0, stageSprites.length - 1)];
				sprite.render(guiGraphics.pose(), lvlX, lvlY);
				
				// current resolve stage
				int curStage = resolve.getCurStage();
				if (curStage >= 0) {
					stageSprites = STAGE_HORIZONTAL;
					sprite = stageSprites[Mth.clamp(curStage, 0, stageSprites.length - 1)];
					sprite.render(guiGraphics.pose(), lvlX, lvlY);
				}
			}
			
			if (resolveEffect == null) {
				float multiplier = resolve.totalMultiplier(user);
				if (multiplier > 1) {
					Component multiplierText = Component.literal("x" + String.format("%.2f", multiplier));
					StandSkin skin = StandSkinsLoader.getCurSkin();
					guiGraphics.drawCenteredString(mc.font, multiplierText, x + width / 2, y - 8, skin != null ? skin.getColors().text() : 0xFFFFFFFF);
				}
			}
		}
		
		@Override
		protected void checkTooltip(double mouseX, double mouseY, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			LivingEntity user = mc.player;
			ResolveCounter resolve = ResolveCounter.getIfEnabled(user);
			if (resolve == null) return;
			
			this.yOffsetU = 4;
			updateRectangle(32, 32);
			
			MultiLineScreenTooltip tooltip;
			double y = mouseY - this.getY();
			if (y <= 8) {
				// Resolve multiplier
				tooltip = new MultiLineScreenTooltip(
						Component.translatable("ripples_hud.resolve_multiplier")
										.withStyle(ChatFormatting.BLACK), 
						Component.translatable("ripples_hud.resolve_multiplier.hp",
								String.format("%.2f", resolve.missingHpMultiplier(user, 0)))
										.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
			}
			else if (y > 24) {
				// Resolve stage
				boolean vampire = !ResolveStageBuffs.getsDamageResFromResolve(user);
				tooltip = new MultiLineScreenTooltip(
						Component.translatable("ripples_hud.resolve_stage",
								resolve.getCurStage() + 1,
								resolve.getUnlockedStage() + 1)
										.withStyle(ChatFormatting.BLACK), 
						Component.translatable("ripples_hud.resolve_stage.desc")
										.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY),
						Component.translatable("ripples_hud.resolve_stage.desc1" + (vampire ? ".vamp" : ""))
										.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
			}
			else {
				int resolveModeTimer = resolve.resolveModeTimer;
				if (resolveModeTimer > 0) {
					// Resolve mode timer
					boolean passedAllStages = ResolveStageBuffs.keepResolveModeAtHalfPassively(resolve, user);
					tooltip = new MultiLineScreenTooltip(
							Component.translatable("ripples_hud.resolve_mode",
									Component.literal(StringUtil.formatTickDuration(resolveModeTimer, mc.level.tickRateManager().tickrate())))
											.withStyle(ChatFormatting.BOLD).withStyle(style -> style.withColor(0xFFC6151F)), 
							Component.translatable("ripples_hud.resolve_mode.desc" + (passedAllStages ? ".free" : ""))
											.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
				}
				else {
					// Resolve bar fill
					tooltip = new MultiLineScreenTooltip(
							Component.translatable("ripples_hud.resolve_bar",
									Component.literal(String.valueOf((int) (resolve.getResolveBarFill() * 100))))
											.withStyle(ChatFormatting.BLACK), 
							Component.translatable("ripples_hud.resolve_bar.desc")
											.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY),
							Component.translatable("ripples_hud.resolve_bar.desc1")
											.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
				}
			}
			this.tooltip.set(tooltip);
			super.checkTooltip(mouseX, mouseY, deltaTracker);
		}
	}
	
	
	public static class Stamina extends HudElement {
		public static final GuiIcon ICON = new GuiIcon(JojoMod.resLoc("textures/hud/stand_stamina.png"), 20, 20);
		public static final ResourceLocation BAR_HORIZONTAL_FILL = JojoMod.resLoc("textures/hud/bars/bar_horizontal_stamina.png");
		public static final ResourceLocation BAR_HORIZONTAL_MINI_FILL = JojoMod.resLoc("textures/hud/bars/bar_horizontal_mini_stamina.png");
		public static final ResourceLocation BAR_VERTICAL_FILL = JojoMod.resLoc("textures/hud/bars/bar_vertical_stamina.png");
		public static final ResourceLocation BAR_VERTICAL_MINI_FILL = JojoMod.resLoc("textures/hud/bars/bar_vertical_mini_stamina.png");
		
		public Bars.BarSize barSize;
		public ElementTransparency miniBarTransparency = new ElementTransparency();

		public Stamina(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public Stamina(String name, SnappingH snappingHorizontal, SnappingV snappingVertical, 
				int xOffset, int yOffset, int width, int height) {
			super(name, snappingHorizontal, snappingVertical, xOffset, yOffset, width, height);
		}
		
		public MultiLineScreenTooltip tooltipResolve;
		
		@Override
		protected void initText() {
			this.tooltipText = new MultiLineScreenTooltip(
					Component.translatable("ripples_hud." + name).withStyle(ChatFormatting.BLACK), 
					Component.translatable("ripples_hud." + name + ".desc", 
							Component.translatable("ripples_hud." + name + ".desc1.regular"))
					.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
			this.tooltipResolve = new MultiLineScreenTooltip(
					Component.translatable("ripples_hud." + name).withStyle(ChatFormatting.BLACK), 
					Component.translatable("ripples_hud." + name + ".desc", 
							Component.translatable("ripples_hud." + name + ".desc1.resolve"))
					.withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
			this.tooltip.set(this.tooltipText);
		}

		@Override
		public boolean shouldRender() {
			barSize = null;
			
			if (hud.forContainerMenu.isTrue() || !JojoMod.config.getCommon().standStamina.getAsBoolean()) return false;
			StandPower standPower = ClientPowerCache.getPower(PowerClass.STAND);
			if (standPower != null && !standPower.isUserCreative() && standPower.usesStamina()) {
				AbilityControlScheme controlScheme = InputHandler.getInstance().getActiveControlScheme();
				if (controlScheme != null && controlScheme.hasAbility(ability -> ability.powerClass() == PowerClass.STAND)) {
					barSize = Bars.BarSize.REGULAR;
					miniBarTransparency.reset();
				}
				else {
					barSize = Bars.BarSize.MINI;
					if (standPower.getStamina() < standPower.getMaxStamina()) {
						miniBarTransparency.reset();
					}
				}
			}
			
			return barSize != null && miniBarTransparency.shouldRender();
		}
		
		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			StandPower standPower = ClientPowerCache.getPower(PowerClass.STAND);
			float partialTick = ClientUtil.partialTick(deltaTracker, false);
			float staminaRatio = standPower.getStaminaRatio(partialTick);
			int x = getX() + 8;
			int y = getY();
			float alpha = Math.max(
					(ResolveStageBuffs.ignoreStaminaDebuff(Minecraft.getInstance().player) ? 0.5f : 1)
					* miniBarTransparency.getAlpha(partialTick), 
					ElementTransparency.MIN_ALPHA);
			PoseStack poseStack = guiGraphics.pose();
			switch (barSize) {
				case REGULAR -> {
					Bars.renderHorizontalBar(poseStack, x, y, staminaRatio, BAR_HORIZONTAL_FILL, BlitFloat.NO_TINT, alpha);
					ICON.render(poseStack, x - 12, y - 6, ARGB.white(alpha));
				}
				case MINI -> {
					Bars.renderHorizontalBarMini(poseStack, x, y, staminaRatio, BAR_HORIZONTAL_MINI_FILL, BlitFloat.NO_TINT, alpha);
					poseStack.pushPose();
					poseStack.translate(x - 6, y - 3, 0);
					poseStack.scale(0.5f, 0.5f, 1);
					ICON.render(poseStack, 0, 0, ARGB.white(alpha));
					poseStack.popPose();
				}
			}
		}
		
		@Override
		protected void checkTooltip(double mouseX, double mouseY, DeltaTracker deltaTracker) {
			StandPower standPower = ClientPowerCache.getPower(PowerClass.STAND);
			
			if (ResolveStageBuffs.ignoreStaminaDebuff(Minecraft.getInstance().player)) {
				this.tooltip.set(this.tooltipResolve);
			}
			else {
				this.tooltip.set(this.tooltipText);
			}
			
			MultiLineScreenTooltip tooltipText = (MultiLineScreenTooltip) this.tooltip.get();
			float value = standPower.getStamina();
			float maxValue = standPower.getMaxStamina();
			float ratio = standPower.getStaminaRatio();
			tooltipText.setTitle(Component.translatable("ripples_hud.stamina_bar",
					Component.literal(String.valueOf((int) value)).withStyle(style -> style.withColor(color(ratio))),
					Component.literal(String.valueOf((int) maxValue))
					).withStyle(ChatFormatting.BLACK));
			super.checkTooltip(mouseX, mouseY, deltaTracker);
		}
		
		public static int color(float ratio) {
			return FastColor.ARGB32.colorFromFloat(1, (1 - ratio) * 0.6f, ratio * 0.6f, 0f);
		}
	}
	
	
	public static class Finisher extends HudElement {
		public static final ResourceLocation[] BARS = {
				JojoMod.resLoc("textures/hud/stand_finisher_1.png"),
				JojoMod.resLoc("textures/hud/stand_finisher_2.png"),
				JojoMod.resLoc("textures/hud/stand_finisher_3.png")
		};
		public static final ResourceLocation[] BARS_FULL = {
				JojoMod.resLoc("textures/hud/stand_finisher_1_full.png"),
				JojoMod.resLoc("textures/hud/stand_finisher_2_full.png")
		};

		public Finisher(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public Finisher(String name, SnappingH snappingHorizontal, SnappingV snappingVertical, 
				int xOffset, int yOffset, int width, int height) {
			super(name, snappingHorizontal, snappingVertical, xOffset, yOffset, width, height);
		}

		@Override
		public boolean shouldRender() {
			if (hud.forContainerMenu.isTrue()) return false;
			StandEntity stand = ClientGlobals.playerStandEntity;
			return stand != null;
		}
		
		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			Minecraft mc = Minecraft.getInstance();
			StandEntity stand = ClientGlobals.playerStandEntity;
			float partialTick = ClientUtil.partialTick(deltaTracker, false);
			float finisher = stand.getFinisherMeter(partialTick);
			
			int crosshairX = (guiGraphics.guiWidth() - 15) / 2;
			int crosshairY = (guiGraphics.guiHeight() - 15) / 2;
			
			float width = getWidth();
			float height = getHeight();
			float x = crosshairX - width / 4;
			float y = crosshairY - height / 4;
			int color = ARGB.white(0.5f);

			int fullFinishers = Mth.floor(finisher);
			if (fullFinishers > 0) {
				BlitFloat.blit(guiGraphics.pose(), mc, BARS_FULL[Math.min(fullFinishers, BARS_FULL.length) - 1], 
						x, y, width, height, 0, 
						color);
			}
			
			float finisherFill = Mth.frac(finisher);
			BlitFloat.blitRadial(guiGraphics.pose(), mc, BARS[Math.min(fullFinishers, BARS.length - 1)], 
					x, y, width, height, 0, 
					0, finisherFill, color);
		}
	}
	
	
	public static class StandRange extends HudElement {

		public StandRange(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public StandRange(String name, SnappingH snappingHorizontal, SnappingV snappingVertical, 
				int xOffset, int yOffset, int width, int height) {
			super(name, snappingHorizontal, snappingVertical, xOffset, yOffset, width, height);
		}

		@Override
		public boolean shouldRender() {
			if (hud.forContainerMenu.isTrue()) return false;
			StandEntity stand = ClientGlobals.playerStandEntity;
			return stand != null && stand.isManuallyControlled();
		}
		
		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			StandEntity stand = ClientGlobals.playerStandEntity;
			double distance = MathUtil.getAABBDistance(stand.getBoundingBox(), stand.getUser().getBoundingBox());
			double damageFactor = stand.rangeEfficiency;
			Font font = Minecraft.getInstance().font;

			int x = this.getX();
			int y = this.getY();
			int width;
			int height;
			Component distanceString = Component.literal(String.format("%.2f m", distance));
			guiGraphics.drawString(font, distanceString, x, y, 0xFFFFFFFF);
			width = font.width(distanceString);
			height = font.lineHeight;
			if (damageFactor < 1) {
				y += 12;
				Component strength = Component.translatable("jojo_ripples.overlay.stand_strength", String.format("%.2f%%", damageFactor * 100F));
				guiGraphics.drawString(font, strength, x, y, 0xFF4040);
				width = Math.max(width, font.width(strength));
				height += 12;
			}
			updateRectangle(width, height);
		}
	}
	
	
	public static class StandToggles extends HudElement {

		public StandToggles(String name, int x0, int y0, int width, int height) {
			super(name, x0, y0, width, height);
		}

		public List<ClientStandToggle> togglesToRender = new ArrayList<>();
		public FloatList transparencies = new FloatArrayList();
		@Override
		public boolean shouldRender() {
			if (hud.forContainerMenu.isTrue()) return false;
			
			togglesToRender.clear();
			transparencies.clear();
			
			ClientStandToggle[] toggles = ClientStandToggles.lazyInitToggles();
			float partialTick = ClientUtil.partialTick(Minecraft.getInstance().getTimer(), false);
			for (var toggle : toggles) {
				boolean alwaysRender = toggle.hudVisibilitySetting.get();
				ElementTransparency fadeOut = toggle.fadeOut;
				if (toggle.activeWhen.getAsBoolean() && (alwaysRender || fadeOut.shouldRender())) {
					togglesToRender.add(toggle);
					transparencies.add(alwaysRender ? 1f : fadeOut.getAlpha(partialTick));
				}
			}
			
			return !togglesToRender.isEmpty();
		}
		
		static final int ICON_SIZE = ClientStandToggle.ICON_SIZE;
		static final int INTERVAL = 2;
		@Override
		public void updateRectangle() {
			int x = getX();
			int y = hud.controls.shouldRender() ? hud.controls.getY() + hud.controls.getHeight() : 4;
			int width = togglesToRender.size() * (ICON_SIZE + INTERVAL) - INTERVAL;
			int height = ICON_SIZE;
			rectangle = new ScreenRectangle(new ScreenPosition(x, y), width, height);
		}
		
		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			int x = getX();
			int y = getY();
			
			PoseStack poseStack = guiGraphics.pose();
			for (int i = 0; i < togglesToRender.size(); i++) {
				ClientStandToggle toggle = togglesToRender.get(i);
				int color = ARGB.white(transparencies.getFloat(i));
				toggle.renderIcon(poseStack, x, y, color);
				x += ICON_SIZE + INTERVAL;
			}
		}
		
		@Override
		protected void checkTooltip(double mouseX, double mouseY, DeltaTracker deltaTracker) {
			ClientStandToggle hoveredToggle = null;
			if (isHovered) {
				int x = (int) mouseX - getX();
				if (x % (ICON_SIZE + INTERVAL) < ICON_SIZE) {
					int index = x / (ICON_SIZE + INTERVAL);
					if (index >= 0 && index < togglesToRender.size()) {
						hoveredToggle = togglesToRender.get(index);
					}
				}
			}
			
			if (hoveredToggle != null) {
				Component text = CommonComponents.optionStatus(
						hoveredToggle.text, hoveredToggle.getResultingValue())
						.withStyle(ChatFormatting.BLACK);
				tooltip.set(Tooltip.create(text));
			}
			else {
				tooltip.set(null);
			}
			super.checkTooltip(mouseX, mouseY, deltaTracker);
		}
		
	}
	
	
	public static class RotpXpBarReplacement extends HudElement {
		public static final ResourceLocation STAND_EXP_BG = JojoMod.resLoc("textures/gui/experience_bar_stand_background.png");
		public static final ResourceLocation STAND_EXP = JojoMod.resLoc("textures/gui/experience_bar_stand_progress.png");
		public static final GuiIcon STAND_EXP_ICON = new GuiIcon(JojoMod.resLoc("textures/gui/sprites/stand_exp.png"), 0, 0, 10, 10, 10, 10);
		public static final ResourceLocation HAMON_EXP_BG = JojoMod.resLoc("textures/gui/experience_bar_hamon_background.png");
		public static final ResourceLocation HAMON_EXP = JojoMod.resLoc("textures/gui/experience_bar_hamon_progress.png");
		public static final ResourceLocation VAMP_LIFEFORCE_BG = JojoMod.resLoc("textures/gui/experience_bar_vamp_background.png");
		public static final ResourceLocation VAMP_LIFEFORCE = JojoMod.resLoc("textures/gui/experience_bar_vamp_progress.png");
		
		@Nullable protected XpBarStuff xpBarStuff;
		
		public RotpXpBarReplacement(String name) {
			super(name, HudElement.SnappingH.CENTER, HudElement.SnappingV.DOWN, 
					0, ChangeXpBar.DOWN_OFFSET - ChangeXpBar.HEIGHT - 2, ChangeXpBar.WIDTH, ChangeXpBar.HEIGHT + 4);
		}
		
		@Override
		public void preRender(GuiGraphics guiGraphics, DeltaTracker deltaTracker, double mouseX, double mouseY) {
			xpBarStuff = null;
			
			if (ChangeXpBar.isXpBarVisible()) {
				xpBarStuff = curXpBarType();
				if (xpBarStuff != null) {
					this.name = "xp_bar." + xpBarStuff.name;
					if (xpBarStuff.tooltipName != null || xpBarStuff.tooltipDesc != null) {
						this.tooltipText = new MultiLineScreenTooltip(
								xpBarStuff.tooltipName != null ? xpBarStuff.tooltipName : 
									Component.translatable("ripples_hud." + name).withStyle(ChatFormatting.BLACK), 
								xpBarStuff.tooltipDesc != null ? xpBarStuff.tooltipDesc : 
									Component.translatable("ripples_hud." + name + ".desc").withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
						this.tooltip.set(this.tooltipText);
					}
					else {
						initText();
					}
					ChangeXpBar.disableVanillaXpBar = true;
				}
			}
		}
		
		@Nullable
		protected XpBarStuff curXpBarType() {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player != null) {
				PowerClass<?> powerClass = hud.powerIcon.powerClass;
				if (powerClass != null) {
					if (powerClass == PowerClass.STAND) {
						StandPower standPower = ClientPowerCache.getPower(PowerClass.STAND);
						if (standPower != null && standPower.hasPower() && standPower.getPowerType().showHUD(standPower)) {
							StandTypePersistentData levelingData = standPower.getCurTypeData();
							if (levelingData != null) {
								StandExpSummary expSummary = levelingData.expSummary(standPower);
								
								int maxPossibleExp = expSummary.total - expSummary.spent;
								int canSpendExp = Math.min(levelingData.getExp(), maxPossibleExp);
								boolean isAtMaxExp = canSpendExp >= maxPossibleExp;
								int expAcquired = canSpendExp + expSummary.spent;
								int expTotalForStand = expSummary.total;
								
								MutableComponent barTooltipName = isAtMaxExp ? 
										Component.translatable("jojo_ripples.stand_exp.bar.full") : 
										Component.translatable("jojo_ripples.stand_exp.bar", canSpendExp, expAcquired, expTotalForStand);
								
								return new XpBarStuff("stand_exp", STAND_EXP_BG, STAND_EXP, 
										(float) expAcquired / (float) expTotalForStand, 
										canSpendExp > 0 ? String.valueOf(canSpendExp) : "", 
										StandSkillsScreen.STAND_EXP_NUMBER_COLOR, null,
										barTooltipName.withStyle(ChatFormatting.BLACK), 
										Component.translatable("jojo_ripples.stand_exp.desc").withStyle(ChatFormatting.ITALIC, ChatFormatting.DARK_GRAY));
							}
						}
					}
					//else if (powerClass == PowerClass.PLAYER_POWER) {
					//	PlayerPower power = ClientPowerCache.getPower(PowerClass.PLAYER_POWER);
					//	if (power != null && power.hasPower()) {
					//		PlayerPowerType<?> powerType = power.getPowerType();
					//		//...
					//	}
					//}
				}
			}
			
			return null;
		}
		
		protected static record XpBarStuff(String name, 
				ResourceLocation backgroundSprite, ResourceLocation progressSprite, 
				float barProgress, String level, int levelColor, @Nullable GuiIcon icon,
				@Nullable Component tooltipName, @Nullable Component tooltipDesc) {}

		@Override
		public boolean shouldRender() {
			return xpBarStuff != null && !hud.forContainerMenu.isTrue();
		}

		@Override
		public void renderElement(GuiGraphics guiGraphics, DeltaTracker deltaTracker) {
			ChangeXpBar.renderXpBar(guiGraphics, 
					xpBarStuff.backgroundSprite, xpBarStuff.progressSprite, 
					xpBarStuff.barProgress, xpBarStuff.level, xpBarStuff.levelColor, xpBarStuff.icon);
		}
		
	}
	
}
