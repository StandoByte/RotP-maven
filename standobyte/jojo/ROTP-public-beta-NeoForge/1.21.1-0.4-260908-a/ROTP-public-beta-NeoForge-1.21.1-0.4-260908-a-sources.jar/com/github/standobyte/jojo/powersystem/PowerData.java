package com.github.standobyte.jojo.powersystem;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.jetbrains.annotations.ApiStatus;

import com.github.standobyte.jojo.network.s2c.PowerDataUnlockedSkillsPacket;
import com.github.standobyte.jojo.network.s2c.TrPowerDataPacket;
import com.github.standobyte.jojo.powersystem.ability.condition.ConditionCheck;
import com.github.standobyte.jojo.powersystem.unlockableskill.UnlockableSkill;
import com.github.standobyte.jojo.util.functions.NBTUtil;

import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.common.util.INBTSerializable;
import net.neoforged.neoforge.network.PacketDistributor;

public abstract class PowerData implements INBTSerializable<CompoundTag> {
	public final PowerType powerType;
	protected final Set<String> _allLockedAbilities = new HashSet<>();
	
	protected Set<String> unlockedSkills = new HashSet<>();
	public Set<String> _lockedAbilities = new HashSet<>();
	
	public PowerData(PowerType powerType) {
		this.powerType = powerType;
		for (var skillEntry : getPowerType().getUnlockableSkills().entrySet()) {
			UnlockableSkill skill = skillEntry.getValue();
			_allLockedAbilities.addAll(skill.unlocksAbilities);
		}
		unlockStartingSkills();
	}
	
	public PowerType getPowerType() {
		return powerType;
	}
	
	public Map<String, ? extends UnlockableSkill> getAllSkills() {
		return powerType.getUnlockableSkills();
	}
	
	protected void unlockStartingSkills() {
		for (var skillEntry : getAllSkills().entrySet()) {
			UnlockableSkill skill = skillEntry.getValue();
			if (skill.isStarting) {
				String skillName = skillEntry.getKey();
				_setSkillUnlocked(skillName, true, false);
			}
		}
	}
	
	
	public void onInit(Power<?> userPower) {}
	
	public void tick(Power<?> userPower) {}
	
	
	public boolean isSkillUnlocked(String skillName) {
		return unlockedSkills.contains(skillName);
	}
	
	public boolean unlockSkill(Power<?> userPower, String skillName) {
		LivingEntity user = userPower.getUser();
		if (user.level().isClientSide()) return false;
		
		PowerType powerType = userPower.getPowerType();
		if (powerType != null && !isSkillUnlocked(skillName)) {
			UnlockableSkill skill = getAllSkills().get(skillName);
			if (skill != null) {
				ConditionCheck canUnlock = skill.canUnlockFromMenu(userPower, this);
				if (canUnlock.positive()) {
					_setSkillUnlocked(skillName, true, true);
					syncUnlockedSkills(user);
					return true;
				}
			}
		}
		return false;
	}

	public void resetUnlockedSkills(Power<?> userPower) {
		LivingEntity user = userPower.getUser();
		if (user.level().isClientSide()) return;
		
		for (var skillEntry : getAllSkills().entrySet()) {
			UnlockableSkill skill = skillEntry.getValue();
			if (!skill.isStarting) {
				String skillName = skillEntry.getKey();
				_setSkillUnlocked(skillName, false, true);
			}
		}
		
		syncUnlockedSkills(user);
	}
	
	@ApiStatus.NonExtendable
	public boolean _setSkillUnlocked(String skillName, boolean unlocked, boolean inGameplay) {
		UnlockableSkill skill = getAllSkills().get(skillName);
		return skill != null ? _setSkillUnlocked(skill, unlocked, inGameplay) : false;
	}
	
	@ApiStatus.Internal
	public boolean _setSkillUnlocked(UnlockableSkill skill, boolean unlocked, boolean inGameplay) {
		if (unlocked) {
			if (unlockedSkills.add(skill.skillName)) {
				_lockedAbilities.removeAll(skill.unlocksAbilities);
				return true;
			}
		}
		else {
			if (unlockedSkills.remove(skill.skillName)) {
				_lockedAbilities.addAll(skill.unlocksAbilities);
				return true;
			}
		}
		
		return false;
	}

	@ApiStatus.Internal
	public void _clearUnlockedSkills() {
		unlockedSkills.clear();
		_lockedAbilities.clear();
		_lockedAbilities.addAll(_allLockedAbilities);
		unlockStartingSkills();
	}
	
	
	public void addAttributeModifiers(LivingEntity user) {}
	
	public void removeAttributeModifiers(LivingEntity user) {}
	

	public abstract PowerClass<?> getPowerClass();
	

	@Override
	public CompoundTag serializeNBT(Provider provider) {
		CompoundTag nbt = new CompoundTag();
		
		ListTag skillsNbt = new ListTag();
		unlockedSkills.forEach(skillName -> skillsNbt.add(StringTag.valueOf(skillName)));
		nbt.put("skills", skillsNbt);

		return nbt;
	}
	
	@Override
	public void deserializeNBT(Provider provider, CompoundTag nbt) {
		_clearUnlockedSkills();
		NBTUtil.getElementOptional(nbt, "skills", ListTag.class).ifPresent(skillsNbt -> {
			if (skillsNbt.getElementType() == Tag.TAG_STRING) {
				for (Tag element : skillsNbt) {
					_setSkillUnlocked(element.getAsString(), true, false);
				}
			}
		});

	}
	
	
	public void toBuf(FriendlyByteBuf buf, boolean isSentToTracking) {
	}
	
	public void fromBuf(FriendlyByteBuf buf, boolean isSentToTracking) {
	}
	
	@ApiStatus.NonExtendable
	public void syncToPlayer(ServerPlayer user) {
		PacketDistributor.sendToPlayer(user, new TrPowerDataPacket(user.getId(), getPowerClass(), this, false));
	}
	
	@ApiStatus.NonExtendable
	public void syncUnlockedSkills(LivingEntity user) {
		if (user instanceof ServerPlayer player) {
			PacketDistributor.sendToPlayer(player, new PowerDataUnlockedSkillsPacket(user.getId(), getPowerClass(), unlockedSkills));
		}
	}

	@ApiStatus.NonExtendable
	public void syncToTracking(LivingEntity user, ServerPlayer tracking) {
		PacketDistributor.sendToPlayer(tracking, new TrPowerDataPacket(user.getId(), getPowerClass(), this, true));
	}

	@ApiStatus.NonExtendable
	public void syncToAllTracking(LivingEntity user) {
		PacketDistributor.sendToPlayersTrackingEntity(user, new TrPowerDataPacket(user.getId(), getPowerClass(), this, true));
	}
	
	public void syncOnUpdate(LivingEntity user) {
		if (!user.level().isClientSide()) {
			syncToAllTracking(user);
			if (user instanceof ServerPlayer player) {
				syncToPlayer(player);
			}
		}
	}
	
	public void clSetUnlockedSkills(Collection<String> fromPacket) {
		_clearUnlockedSkills();
		for (String skillName : fromPacket) {
			_setSkillUnlocked(skillName, true, false);
		}
	}
	
}
