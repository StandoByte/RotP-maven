package com.github.standobyte.jojo.powersystem.unlockableskill;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.github.standobyte.jojo.client.standskin.text.StandSkinComponent;
import com.github.standobyte.jojo.powersystem.Power;
import com.github.standobyte.jojo.powersystem.PowerClass;
import com.github.standobyte.jojo.powersystem.PowerData;
import com.github.standobyte.jojo.powersystem.ability.condition.ConditionCheck;
import com.github.standobyte.jojo.powersystem.standpower.StandInstance;
import com.github.standobyte.jojo.powersystem.standpower.StandPower;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

// XXX tick the unlocked stand skills
// TODO hidden skills
public abstract class UnlockableSkill {
	public final String skillName;
	public boolean isStarting;
	public boolean hidden;
	public List<String> prerequisiteSkills;
	public Optional<String> mainSkill;
	public List<String> unlocksAbilities;
	
	public DevStatus implemented = DevStatus.IMPLEMENTED;
	
	public String tlKeyName;
	public String tlKeyDesc;
	public String tlKeyControls;

	public UnlockableSkill(String name) {
		this.skillName = name;
		this.prerequisiteSkills = new ArrayList<>();
		this.mainSkill = Optional.empty();
		this.unlocksAbilities = new ArrayList<>();
		tlKeyName = "jojo_ripples.skill." + name;
		tlKeyDesc = tlKeyName + ".desc";
		tlKeyControls = tlKeyName + ".controls";
	}
	
	public ConditionCheck canUnlockFromMenu(Power<?> userPower, PowerData data) {
		List<String> missingPrerequsites = null;
		for (String prerequisite : prerequisiteSkills) {
			if (!data.isSkillUnlocked(prerequisite)) {
				if (missingPrerequsites == null) missingPrerequsites = new ArrayList<>(prerequisiteSkills.size());
				missingPrerequsites.add(prerequisite);
			}
		}
		if (missingPrerequsites != null) {
			MutableComponent allNames = Component.empty();
			int count = missingPrerequsites.size();
			
			StandPower asStandPower = PowerClass.STAND.cast(userPower);
			StandInstance stand = asStandPower != null ? asStandPower.getStandInstance().orElse(null) : null;
			
			for (int i = 0; i < count; i++) {
				String skill = missingPrerequsites.get(i);
				MutableComponent skillName = StandSkinComponent.translatable(stand, "jojo_ripples.skill." + skill);
				allNames = allNames.append(Component.translatable("jojo_ripples.list.entry", skillName));
			}
			Component fullMessage = Component.translatable("jojo_ripples.stand_skills.prerequisites", allNames);
			return ConditionCheck.createNegative(fullMessage);
		}
		
		return ConditionCheck.POSITIVE;
	}
	
	// Initialization methods
	
	public UnlockableSkill setIsStartingSkill() {
		this.isStarting = true;
		return this;
	}
	
	@Deprecated
	public UnlockableSkill setIncomplete() {
		this.implemented = DevStatus.WIP;
		return this;
	}
	
	@Deprecated
	public UnlockableSkill setNotYetImplemented() {
		this.implemented = DevStatus.NYI;
		return this;
	}
	
	
	public UnlockableSkill withAbility(String abilityName, String... extra) {
		this.unlocksAbilities.add(abilityName);
		Collections.addAll(this.unlocksAbilities, extra);
		return this;
	}
	
	public UnlockableSkill prerequisiteSkill(String name, String... other) {
		this.prerequisiteSkills.add(name);
		Collections.addAll(this.prerequisiteSkills, other);
		return this;
	}
	
	public enum DevStatus {
		IMPLEMENTED,
		WIP,
		NYI
	}
	
}
