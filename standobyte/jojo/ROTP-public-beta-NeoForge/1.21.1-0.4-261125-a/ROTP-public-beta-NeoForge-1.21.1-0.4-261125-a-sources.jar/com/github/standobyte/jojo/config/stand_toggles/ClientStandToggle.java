package com.github.standobyte.jojo.config.stand_toggles;

import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.github.standobyte.jojo.client.ui.KeybindsEditingUI;
import com.github.standobyte.jojo.client.ui.hud_power.PowerHudControlsElement;
import com.github.standobyte.jojo.client.ui.screen_widgets.ToggleButton;
import com.github.standobyte.jojo.client.ui.screen_widgets.ToggleSwitch;
import com.github.standobyte.jojo.client.ui.utils.Alignment;
import com.github.standobyte.jojo.client.ui.utils.BlitFloat;
import com.github.standobyte.jojo.client.ui.utils.ElementTransparency;
import com.github.standobyte.jojo.client.ui.utils.GuiIcon;
import com.github.standobyte.jojo.client.ui.utils.tooltip.TooltipParams;
import com.github.standobyte.jojo.config.BoolOrPlayerPref;
import com.github.standobyte.jojo.config.client.ScrollingStringButton;
import com.github.standobyte.jojo.config.core.ConfigOption;
import com.github.standobyte.jojo.config.core.ModConfigType;
import com.github.standobyte.jojo.config.internal.ConfigNetworkFunctions;
import com.github.standobyte.jojo.core.JojoMod;
import com.github.standobyte.jojo.powersystem.PowerClass;
import com.github.standobyte.jojo.powersystem.standpower.StandPower;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.layouts.LinearLayout.Orientation;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.neoforged.neoforge.common.util.Lazy;

public class ClientStandToggle implements Renderable {
	public final ConfigOption<Boolean> setting;
	@Nullable public final ConfigOption<BoolOrPlayerPref> overrulingCommonSetting;
	public final ModConfigType configToSave;
	public final Component text;
	
	public final ConfigOption<Boolean> hudVisibilitySetting;
	public final GuiIcon hudIcon;
	@Nullable public final GuiIcon offHudIcon;
	
	public final Lazy<KeyMapping> keybind;
	
	public ToggleSwitch toggle;
	public Button keybindButton;
	public ToggleButton visibilityToggle;
	public ElementTransparency fadeOut = new ElementTransparency();
	
	public ClientStandToggle(ConfigOption<Boolean> setting, @Nullable ConfigOption<BoolOrPlayerPref> overrulingCommonSetting,
			ModConfigType configToSave, 
			ConfigOption<Boolean> hudVisibilitySetting, 
			Supplier<KeyMapping> keybind, 
			GuiIcon icon, @Nullable GuiIcon offIcon, Component text) {
		this.setting = setting;
		this.overrulingCommonSetting = overrulingCommonSetting;
		this.configToSave = configToSave;
		this.keybind = Lazy.of(keybind);
		this.text = text;
		
		this.hudVisibilitySetting = hudVisibilitySetting;
		this.hudIcon = icon;
		this.offHudIcon = offIcon;
	}
	
	/** @return If the toggle should show up in the Stand toggles JoJo menu tab */
	public boolean isAvailable(StandPower standPower) {
		return standPower != null && standPower.hasPower();
	}

	/** @return If the toggle should show up in the Stand toggles JoJo menu tab, and the key press should toggle it */
	public boolean isAvailableAndActive(StandPower standPower) {
		return isAvailable(standPower) && PowerHudControlsElement.controlsHaveTypeAndAbility(PowerClass.STAND, null);
	}
	
	public void init(int x, int y, KeybindsEditingUI keybindsHandler) {
		KeyMapping keyMapping = keybind.get();
		if (keyMapping != null) {
			keybindButton = keybindsHandler.addKeybind(keyMapping, JojoMod.config::saveClient, x + 155, y, 50, 20).button;
		}
		
		toggle = new ToggleSwitch(x + 4, y + 2, Orientation.HORIZONTAL, 
				setting, 
				newVal -> toggle(), null) {
			
			@Override
			public boolean getStateToRender() {
				return getResultingValue();
			}
		};
		
		visibilityToggle = ToggleButton.visibility(x + 211, y + 5, 10, 10, 
				hudVisibilitySetting, 
				newVal -> {
					hudVisibilitySetting.set(newVal);
					
					JojoMod.config.saveClient();
				}, null);
	}
	
	public void toggle() {
		setting.setWithCallback(!setting.get(), Minecraft.getInstance().player);
		
		JojoMod.config.saveClient();
		if (ConfigNetworkFunctions.clientIsConnectedToAServer()) {
			JojoMod.config.sendClientBroadcast(true);
		}
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
		toggle.active = clientCanToggle();
		MutableComponent toggleTooltip;
		if (!clientCanToggle()) {
			toggleTooltip = Component.translatable("jojo_ripples.toggle_overruled", 
					overrulingCommonSetting.get().optionStatus);
		}
		else {
			toggleTooltip = BoolOrPlayerPref.optionStatus(getResultingValue()).copy();
		}
		toggle.setTooltip(Tooltip.create(toggleTooltip.withStyle(ChatFormatting.BLACK)));
		
		visibilityToggle.setTooltip(Tooltip.create(BoolOrPlayerPref.optionStatus(
				Component.translatable("jojo_ripples.toggle.show_in_hud"), visibilityToggle.getState())
				.copy().withStyle(ChatFormatting.BLACK)));
		
		toggle.render(guiGraphics, mouseX, mouseY, partialTick);
		
		int x = toggle.getX();
		int y = toggle.getY();
		RenderSystem.enableBlend();
		renderIcon(guiGraphics.pose(), x + 28, y - 4);
		ScrollingStringButton._renderScrollingString(guiGraphics, Minecraft.getInstance().font, 
				text, Alignment.LEFT, 
				x + 52, y, x + 150, y + 16, 
				0xFF000000, false, StandTogglesScreen.openedAt);
		if (keybindButton != null) keybindButton.render(guiGraphics, mouseX, mouseY, partialTick);
		visibilityToggle.render(guiGraphics, mouseX, mouseY, partialTick);
		
		if (toggle.isHovered() || visibilityToggle.isHovered()) {
			TooltipParams.set(TooltipParams.paperStyle(1));
		}
	}

	public static final GuiIcon SWITCH_DISABLED = new GuiIcon(JojoMod.resLoc("textures/gui/sprites/hud_switch_disabled.png"), 20, 20);
	public void renderIcon(PoseStack poseStack, int x, int y) { renderIcon(poseStack, x, y, BlitFloat.NO_TINT); }
	public void renderIcon(PoseStack poseStack, int x, int y, int color) {
		boolean value = this.getResultingValue();
		if (value || this.offHudIcon == null) {
			_renderIcon(this.hudIcon, poseStack, x, y, color);
		}
		if (!value) {
			if (this.offHudIcon != null) {
				_renderIcon(this.offHudIcon, poseStack, x, y, color);
			}
			else {
				_renderIcon(SWITCH_DISABLED, poseStack, x, y, color);
			}
		}
	}
	
	public static final int ICON_SIZE = 24;
	protected static void _renderIcon(GuiIcon icon, PoseStack poseStack, int x, int y, int color) {
		int offset = (int) (ICON_SIZE - icon.width) / 2;
		icon.render(poseStack, x + offset, y + offset, color);
	}
	
	public boolean getResultingValue() {
		if (overrulingCommonSetting != null) {
			Boolean commonValue = overrulingCommonSetting.get().asBoolean;
			if (commonValue != null) {
				return commonValue;
			}
		}
		
		return setting.get();
	}
	
	public boolean clientCanToggle() {
		return overrulingCommonSetting == null || overrulingCommonSetting.get() == BoolOrPlayerPref.PLAYER_PREFERENCE;
	}
	
}
