package com.github.standobyte.jojo.util.objects_mc;

import java.util.UUID;

import javax.annotation.Nullable;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class EntityResolver {
	protected static final int EMPTY_NETWORK_ID = 0; // Entity.ENTITY_COUNTER starts with 1, since they use AtomicInteger#incrementAndGet() when assigning entity ids
	protected Entity entity;
	protected LivingEntity entityLiving;
	protected UUID entityUUID;
	protected int entityNetworkId = EMPTY_NETWORK_ID;
	
	public EntityResolver() {}
	
	public void setEntity(@Nullable Entity owner) {
		this.entityUUID = owner != null ? owner.getUUID() : null;
		_assignNetworkId(owner != null ? owner.getId() : EMPTY_NETWORK_ID);
		_setNewEntity(owner);
	}

	public void setEntityUUID(UUID ownerUuid) {
		this.entityUUID = ownerUuid;
	}

	public Entity getEntity(Level level) {
		updateEntity(level);
		return entity;
	}

	public LivingEntity getEntityLiving(Level level) {
		updateEntity(level);
		return entityLiving;
	}

	public void updateEntity(Level level) {
		if (entity != null && entity.isRemoved()) {
			_setNewEntity(null);
		}
		if (entity == null) {
			if (entityUUID != null && level instanceof ServerLevel) {
				_setNewEntity(((ServerLevel) level).getEntity(entityUUID));
			} else if (entityNetworkId != EMPTY_NETWORK_ID) {
				_setNewEntity(level.getEntity(entityNetworkId));
			}
		}
	}

	public boolean hasEntityId() {
		return entityNetworkId != EMPTY_NETWORK_ID;
	}

	protected void _setNewEntity(Entity entity) {
		this.entity = entity;
		this.entityLiving = entity instanceof LivingEntity ? (LivingEntity) entity : null;
		_assignNetworkId(entity != null ? entity.getId() : EMPTY_NETWORK_ID);
	}
	
	protected void _assignNetworkId(int id) {
		this.entityNetworkId = id;
	}



	public void saveNbt(CompoundTag nbt, String key) {
		if (entityUUID != null) {
			nbt.putUUID(key, entityUUID);
		}
	}

	public void loadNbt(CompoundTag nbt, String key) {
		setEntityUUID(nbt.hasUUID(key) ? nbt.getUUID(key) : null);
	}

	public void writeNetwork(FriendlyByteBuf buf) {
		buf.writeInt(entityNetworkId);
	}

	public void readNetwork(FriendlyByteBuf buf) {
		_assignNetworkId(buf.readInt());
	}

	public int getNetworkId() {
		return entityNetworkId;
	}


	public static class Generic<T extends Entity> extends EntityResolver {
		protected final Class<T> entityClass;
		protected T castEntity;

		public Generic(Class<T> entityClass) {
			this.entityClass = entityClass;
		}

		public T getEntityCast(Level world) {
			updateEntity(world);
			return castEntity;
		}

		@Override
		protected void _setNewEntity(Entity entity) {
			super._setNewEntity(entity);
			this.castEntity = entity != null && entityClass.isAssignableFrom(entity.getClass()) ? (T) entity : null;
		}
	}
}
