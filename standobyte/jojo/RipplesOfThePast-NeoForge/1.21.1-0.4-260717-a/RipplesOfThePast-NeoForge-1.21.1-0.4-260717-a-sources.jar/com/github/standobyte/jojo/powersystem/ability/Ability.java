package com.github.standobyte.jojo.powersystem.ability;

import javax.annotation.Nullable;

import org.jetbrains.annotations.ApiStatus;

import com.github.standobyte.jojo.client.ClientProxy;
import com.github.standobyte.jojo.client.input.AbilityInputState;
import com.github.standobyte.jojo.client.input.InputHandler;
import com.github.standobyte.jojo.client.standskin.text.StandSkinComponent;
import com.github.standobyte.jojo.client.ui.hud_power.WindupIndicator;
import com.github.standobyte.jojo.client.ui.utils.BlitFloat;
import com.github.standobyte.jojo.powersystem.Power;
import com.github.standobyte.jojo.powersystem.PowerData;
import com.github.standobyte.jojo.powersystem.ability.condition.AbilityUsageContext;
import com.github.standobyte.jojo.powersystem.ability.condition.AvailableAbilities;
import com.github.standobyte.jojo.powersystem.ability.condition.ConditionCheck;
import com.github.standobyte.jojo.powersystem.ability.condition.AvailableAbilities.AbilityConditionCheck;
import com.github.standobyte.jojo.powersystem.ability.controls.InputMethod;
import com.github.standobyte.jojo.powersystem.ability.cooldown.AbilityCooldownTracker;
import com.github.standobyte.jojo.powersystem.ability.finisher.AbilityStandFinisherData;
import com.github.standobyte.jojo.powersystem.ability.input.ActionInputBuffer.BufferingState;
import com.github.standobyte.jojo.powersystem.entityaction.HeldInput;
import com.github.standobyte.jojo.util.functions.StringUtil;
import com.google.gson.JsonObject;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

public class Ability {
	public final AbilityType<?> abilityType;
	public final AbilityId abilityId;
	protected String spriteName;
	protected String nameTlKey;
	
	public AbilityUsageGroup usageGroup = AbilityUsageGroup.SPECIAL;
	public boolean isSubAbility = false;
	
	@Nullable public AbilityStandFinisherData isStandFinisherOf = null;

	public Ability(AbilityType<?> abilityType, AbilityId abilityId) {
		this.abilityType = abilityType;
		this.abilityId = abilityId;
		this.spriteName = StringUtil.splitIntAtTheEnd(abilityId.nameInMoveset()).getFirst();
		this.nameTlKey = tlKey(abilityId.nameInMoveset());
		this.name = Component.translatable(nameTlKey);
		String abilityName = abilityId.nameInMoveset();
		this.isSubAbility = !abilityName.isEmpty() && Character.isDigit(abilityName.charAt(abilityName.length() - 1));
		initVariationAssets();
	}
	
	public AbilityId getAbilityId() {
		return abilityId;
	}
	
	public final String name() {
		return abilityId.nameInMoveset();
	}
	
	public Power<?> getUserPower(LivingEntity user) {
		return this.abilityId.powerClass().get(user);
	}
	
	public boolean addToControlSchemeEditing() {
		return !isSubAbility;
	}
	
	
	public AbilityUsageGroup getAbilityUsageCategory() {
		return usageGroup;
	}
	
	
	public void initIsFinisher(String basePunchName) { initIsFinisher(basePunchName, 1); }
	public void initIsFinisher(float finisherValue) { initIsFinisher("heavy_punch", finisherValue); }
	public void initIsFinisher() { initIsFinisher("heavy_punch", 1); }
	public void initIsFinisher(String basePunchName, float finisherValue) {
		this.isStandFinisherOf = new AbilityStandFinisherData(basePunchName, finisherValue);
		this.isSubAbility = true;
	}
	
	
	public void initIsGrabVariation() {
		usageGroup = AbilityUsageGroup.GRAB;
		isSubAbility = true;
		this.spriteName = abilityId.nameInMoveset().replace("grab_", "");
		this.nameTlKey = tlKey(spriteName);
	}
	
	
	// Most of the methods below are called in AvailableAbilities#update(Power, Moveset)

	/**
	 * @deprecated Override {@link Ability#replaceWithSubAbility(Power, AvailableAbilities)} instead, this one is not used.
	 */
	@Deprecated
	public Ability replaceWithSubAbility(Power<?> context) {
		return replaceWithSubAbility(context, null);
	}
	
	/**
	 * @return A variation of this ability depending on the context
	 * (e.g. a specific punch in a combo string, a heavy punch finisher, etc.).
	 * You should also call {@link Ability#isAbilityAvailable(Power)} on each candidate yourself,
	 * to make sure the ability shows up when and only when it is unlocked.
	 */
	@ApiStatus.OverrideOnly
	@Nullable
	public Ability replaceWithSubAbility(Power<?> context, AvailableAbilities abilities) {
		return this;
	}
	
	/**
	 * Whether or not the ability should be visible in the HUD and available to the user.
	 * @return true if the ability is unlocked by the user, 
	 * and it makes sense for it to show up in the HUD in the current context 
	 * (e.g. only show the "Use item" ability if the Stand is holding an item).
	 */
	@ApiStatus.OverrideOnly
	public boolean isAbilityAvailable(Power<?> context) {
		return isAbilityUnlocked(context);
	}
	
	public boolean isAbilityUnlocked(Power<?> context) {
		return isSkillUnlocked(context, name());
	}
	
	protected static boolean isSkillUnlocked(Power<?> context, String skillName) {
		PowerData skillsData = context.getCurTypeData();
		return skillsData != null && !skillsData._lockedAbilities.contains(skillName);
	}
	
	/**
	 * A version of {@link Ability#checkSpecificConditions(Power)} with more control, allowing one ability to disable others dynamically
	 */
	// FIXME target parameter (or a simple enough getter)
	public void onConditionCheck(AbilityUsageContext context, AvailableAbilities abilities, AbilityConditionCheck thisAbility) {
		ConditionCheck check = checkConditions(context);
		thisAbility.conditionCheck = check;
		
		Power<?> power = context.power;
		LivingEntity user = power.getUser();
		if (user != null && user.level().isClientSide() && user == ClientProxy.getClientPlayer()) {
			thisAbility.clientInputState = cl_abilityInputState(power)._value;
		}
	}
	
	public ConditionCheck checkConditions(AbilityUsageContext context) {
		ConditionCheck check = checkMainModLogicConditions(context);
		if (check.positive()) {
			check = checkSpecificConditions(context.power);
		}
		return check;
	}
	
	protected boolean canUseInStoppedTime = false;
	@ApiStatus.Internal
	public ConditionCheck checkMainModLogicConditions(AbilityUsageContext context) {
		if (!canUseInStoppedTime && context.isFrozenInTime) {
			return ConditionCheck.NEGATIVE;
		}
		LivingEntity user = context.power.getUser();
		AbilityCooldownTracker cooldowns = AbilityCooldownTracker.get(user);
		if (cooldowns != null && cooldowns.isOnCooldown(this)) {
			return ConditionCheck.NEGATIVE;
		}
		
		return ConditionCheck.POSITIVE;
	}
	
	@ApiStatus.OverrideOnly
	public ConditionCheck checkSpecificConditions(Power<?> context) {
		if (isStandFinisherOf != null) {
			return ConditionCheck.GREEN_HIGHLIGHT;
		}
		return ConditionCheck.POSITIVE;
	}
	
	/**
	 * Is only called on physical client side, can be used to override whether or not an ability
	 * shows up in the HUD and if the input is active.
	 * For example, abilities that are used on items in the inventory (Crazy D's Item repair or item marking abilities)
	 * don't show up in the HUD regularly, but are active when you're hovering over a fitting item.
	 * This method is only called on the client, so it can reference client-only classes and methods.
	 */
	public AbilityInputState cl_abilityInputState(Power<?> context) {
		AbilityInputState state = AbilityInputState.init();
		if (InputHandler.inputsDisabled || InputHandler.isNonWheelScreenOpened()) {
			state.setFlag(AbilityInputState.IS_ACTIVE, false);
			state.setFlag(AbilityInputState.VISIBLE_WHEN_INACTIVE, true);
		}
		return state;
	}
	
	@Nullable
	public WindupIndicator cl_windupIndicator(LivingEntity clientPlayer, WindupIndicator indicator, float partialTick) {
		return null;
	}
	
	public Component getName(Power<?> context) {
		return StandSkinComponent.translatable(context, nameTlKey);
	}
	
	public static String tlKey(AbilityId abilityId, String postfix) {
		return tlKey(abilityId.nameInMoveset() + postfix);
	}
	
	public static String tlKey(String abilityName) {
		return "jojo_ripples.ability." + abilityName;
	}
	
	public String getSpriteName(Power<?> context) {
		return spriteName;
	}
	
	public void renderAbilityIcon(Power<?> context, GuiGraphics guiGraphics, TextureAtlasSprite sprite, float x, float y, int color) {
		BlitFloat.blit(guiGraphics.pose(), Minecraft.getInstance(), sprite, x, y, 16, 16, 0, color);
	}
	
	// 
	
	
	public void writeExtraInput(FriendlyByteBuf serverboundBuf, LivingEntity user, boolean isClientPlayer) {}

	
	/**
	 * Is called in {@link com.github.standobyte.jojo.powersystem.ability.input.AbilityInput}
	 */
	@ApiStatus.OverrideOnly
	@Nullable
	public HeldInput onKeyPress(Level level, LivingEntity user, FriendlyByteBuf extraClientInput, 
			InputMethod inputMethod, float clickHoldResolveTime, BufferingState bufferingState) {
		bufferingState.isActionSuccess = true;
		onKeyPress(level, user, extraClientInput, inputMethod, clickHoldResolveTime);
		onClick(level, user, extraClientInput);
		return null;
	}
	
	/** @deprecated Add a {@link BufferingState} argument to the end of this method's signature when overriding it. */
	@Deprecated
	public HeldInput onKeyPress(Level level, LivingEntity user, FriendlyByteBuf extraClientInput, 
			InputMethod inputMethod, float clickHoldResolveTime) {
		return null;
	}

	/**
	 * A simplified version of {@link Ability#onKeyPress(Level, LivingEntity, FriendlyByteBuf, InputMethod, float)}, 
	 * when all you want is to just do something the moment user clicks the ability
	 */
	@ApiStatus.OverrideOnly
	public void onClick(Level level, LivingEntity user, FriendlyByteBuf extraClientInput) {}
	
	
	public JsonObject toConfigJson() {
		JsonObject json = new JsonObject();
		return json;
	}
	
	public void applyConfig(JsonObject config) {
		// TODO (ability config) reflection to edit field values?
	}
	
	
	protected void initVariationAssets() {}


	@Deprecated protected Component name;
	@Deprecated
	protected static Component abilityName(AbilityId abilityId, String postfix) {
		return Component.translatable("jojo_ripples.ability." + abilityId.nameInMoveset() + postfix);
	}
}
