package com.github.standobyte.jojo.core.packet.fromserver;

import java.util.Optional;

import com.github.standobyte.jojo.client.ClientProxy;
import com.github.standobyte.jojo.core.PacketsRegister;
import com.github.standobyte.jojo.powersystem.standpower.StandInstance;
import com.github.standobyte.jojo.powersystem.standpower.StandPower;
import com.github.standobyte.jojo.powersystem.standpower.type.StandTypePersistentData;
import com.github.standobyte.jojo.util.network.NetworkUtil;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class TrPowerStandInstancePacket implements CustomPacketPayload {
	private final int entityId;
	private final Optional<StandInstance.NetworkData> standInstance;
	private boolean isSentToTracking;
	private StandTypePersistentData serverPerStandTypeData;
	private FriendlyByteBuf clientPerStandTypeData;
	
	public TrPowerStandInstancePacket(int entityId, Optional<StandInstance> standInstance, 
			StandTypePersistentData playerStandTypeData, boolean isSentToTracking) {
		this(entityId, isSentToTracking, 
				standInstance.map(StandInstance.NetworkData::wrap), 
				playerStandTypeData);
	}
	
	private TrPowerStandInstancePacket(int entityId, boolean isSentToTracking, 
			Optional<StandInstance.NetworkData> standInstance, 
			StandTypePersistentData playerStandTypeData) {
		this.entityId = entityId;
		this.standInstance = standInstance;
		this.isSentToTracking = isSentToTracking;
		this.serverPerStandTypeData = playerStandTypeData;
	}
	
	
	private static CustomPacketPayload.Type<TrPowerStandInstancePacket> type;
	
	public static class Handler implements PacketsRegister.PacketOGHandler<TrPowerStandInstancePacket> {
		
		public Handler(ResourceLocation packetId) { 
			type = new CustomPacketPayload.Type<>(packetId);
		}

		@Override
		public Type<TrPowerStandInstancePacket> type() {
			return type;
		}

		public static final StreamCodec<FriendlyByteBuf, Optional<StandInstance.NetworkData>> STAND_INSTANCE_OPTIONAL_CODEC = 
				StandInstance.NetworkData.NETWORK_CODEC.apply(ByteBufCodecs::optional);
		@Override
		public void encode(TrPowerStandInstancePacket packet, RegistryFriendlyByteBuf buf) {
			buf.writeInt(packet.entityId);
			buf.writeBoolean(packet.isSentToTracking);
			STAND_INSTANCE_OPTIONAL_CODEC.encode(buf, packet.standInstance);
			if (packet.serverPerStandTypeData != null) {
				packet.serverPerStandTypeData.toBuf(buf, packet.isSentToTracking);
			}
		}

		@Override
		public TrPowerStandInstancePacket decode(RegistryFriendlyByteBuf buf) {
			TrPowerStandInstancePacket packet = new TrPowerStandInstancePacket(
					buf.readInt(), 
					buf.readBoolean(), 
					STAND_INSTANCE_OPTIONAL_CODEC.decode(buf),
					null);
			packet.clientPerStandTypeData = NetworkUtil.extraPacketData(buf);
			return packet;
		}

		@Override
		public void handle(TrPowerStandInstancePacket payload, IPayloadContext context) {
			Entity entity = ClientProxy.getEntityById(payload.entityId);
			if (entity instanceof LivingEntity living) {
				StandPower standPower = StandPower.get(living);
				if (standPower != null) {
					standPower.setStandInstance(payload.standInstance.map(StandInstance.NetworkData::get));
					var perTypePlayerData = standPower.getCurTypeData();
					if (perTypePlayerData != null) {
						perTypePlayerData.fromBuf(payload.clientPerStandTypeData, payload.isSentToTracking);
					}
				}
			}
		}
		
	}
	
	@Override
	public Type<? extends CustomPacketPayload> type() {
		return type;
	}

}
