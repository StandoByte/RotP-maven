package com.github.standobyte.jojo.powersystem.standpower.effect;

import java.util.Comparator;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Stream;

import org.jetbrains.annotations.ApiStatus;

import com.github.standobyte.jojo.powersystem.standpower.StandPower;

import it.unimi.dsi.fastutil.ints.Int2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

public class UserStandEffects {
	public static final AtomicInteger EFFECTS_COUNTER = new AtomicInteger();
	protected StandPower standPower;
	protected final Int2ObjectMap<StandEffectInstance> effects = new Int2ObjectLinkedOpenHashMap<>();

	public UserStandEffects(StandPower standPower) {
		this.standPower = standPower;
	}

	public void addEffect(StandEffectInstance instance) {
		LivingEntity user = standPower.getUser();
		if (!user.level().isClientSide()) {
			instance.withId(EFFECTS_COUNTER.incrementAndGet());
		}
		putEffectInstance(instance);
		if (!user.level().isClientSide()) {
			PacketDistributor.sendToPlayersTrackingEntity(user, TrStandEffectPacket.add(instance, false));
			if (user instanceof ServerPlayer) {
				PacketDistributor.sendToPlayer((ServerPlayer) user, TrStandEffectPacket.add(instance, true));
			}
		}
	}

	protected void putEffectInstance(StandEffectInstance instance) {
		instance.withStand(standPower);
		effects.put(instance.getId(), instance);
		instance.onStart();
	}

	public void removeEffect(StandEffectInstance instance) {
		if (instance != null) {
			onEffectRemoved(instance);
			effects.remove(instance.getId());
		}
	}

//	public void onUserStandRemoved(LivingEntity user) {
//		effects.values().forEach(effect -> effect.onStop());
//		effects.clear();
//		if (!user.level.isClientSide()) {
//			PacketManager.sendToClientsTrackingAndSelf(TrStandEffectPacket.removeAll(user), user);
//		}
//	}

	public StandEffectInstance getById(int id) {
		return effects.get(id);
	}


	@SuppressWarnings("unchecked")
	public <T extends StandEffectInstance> Optional<T> getEffectTargeting(StandEffectType<T> effectType, LivingEntity target) {
		Stream<StandEffectInstance> effects = getEffects().filter(effect -> 
		effect.effectType == effectType && 
		(target == null ? effect.getTargetUUID() == null : target.getUUID().equals(effect.getTargetUUID())));
		Optional<T> effect = (Optional<T>) effects.findFirst();
		return effect;
	}

	public <T extends StandEffectInstance> T getOrCreateEffect(StandEffectType<T> effectType, LivingEntity target) {
		Optional<T> effect = getEffectTargeting(effectType, target);
		if (effect.isPresent()) {
			return effect.get();
		}
		else {
			T newEffect = effectType.create(standPower.getUser().level());
			addEffect(newEffect.withTarget(target));
			return newEffect;
		}
	}

	@SuppressWarnings("unchecked")
	public <T extends StandEffectInstance> T getOrCreateEffect(StandEffectType<T> effectType) {
		Optional<T> effect = (Optional<T>) getEffects()
				.filter(e -> e.effectType == effectType)
				.findFirst();
		if (effect.isPresent()) {
			return effect.get();
		}
		else {
			T newEffect = effectType.create(standPower.getUser().level());
			addEffect(newEffect);
			return newEffect;
		}
	}

	@SuppressWarnings("unchecked")
	public <T extends StandEffectInstance> Stream<T> getEffectsOfType(StandEffectType<T> type) {
		return (Stream<T>) getEffects()
				.filter(effect -> effect.effectType == type);
	}

	public <T extends StandEffectInstance> Optional<T> getEffectOfType(StandEffectType<T> type) {
		return getEffectsOfType(type).findFirst();
	}


	public static <T extends StandEffectInstance> Stream<T> getEffectsOfType(LivingEntity user, StandEffectType<T> type) {
		StandPower power = StandPower.get(user);
		return power != null ? power.userStandEffects.getEffectsOfType(type) : null;
	}

	public static <T extends StandEffectInstance> Optional<T> getEffectOfType(LivingEntity user, StandEffectType<T> type) {
		StandPower power = StandPower.get(user);
		return power != null ? power.userStandEffects.getEffectOfType(type) : null;
	}
	
	public static <T extends StandEffectInstance> Stream<T> getEffectsInRange(StandPower power, StandEffectType<T> type, double range, LivingEntity user) {
		double rangeSqr = range * range;
		return power.userStandEffects.getEffectsOfType(type)
				.filter(effect -> {
					Entity target = effect.getTarget();
					return target != null && target.distanceToSqr(user) < rangeSqr;
				});
	}

	@SuppressWarnings("unchecked")
	public static <T extends StandEffectInstance> Optional<T> getEffectLookedAt(StandPower power, StandEffectType<T> type, double range, LivingEntity user) {
		return (Optional<T>) getTargetLookedAt(getEffectsInRange(power, type, range, user), user);
	}

	public static Optional<StandEffectInstance> getTargetLookedAt(Stream<? extends StandEffectInstance> targets, LivingEntity user) {
		Vec3 lookAngle = user.getLookAngle();
		Vec3 eyePos = user.getEyePosition(1.0F);
		return targets.max(Comparator.comparingDouble(
				e -> lookAngle.dot(e.getTarget().getBoundingBox().getCenter().subtract(eyePos).normalize())))
				.map(Function.identity());
	}

	public Stream<StandEffectInstance> getEffects() {
		return effects.values().stream();
	}

	@SuppressWarnings("unchecked")
	public static <T extends StandEffectInstance> Stream<T> getEffectsTargetedBy(LivingEntity entity, StandEffectType<T> type) {
		return (Stream<T>) StandEffectsTarget.getEffectsReadOnly(entity).filter(effect -> effect.effectType == type);
	}

	public static boolean isTargetedBy(LivingEntity entity, StandEffectType<?> type) {
		return getEffectsTargetedBy(entity, type).findAny().isPresent();
	}


	@ApiStatus.Internal
	public void setPowerData(StandPower standPower) {
		this.standPower = standPower;
		effects.values().forEach(effect -> effect.withStand(standPower));
	}

	@ApiStatus.Internal
	public void tick() {
		if (effects.isEmpty()) {
			return;
		}

		var it = effects.int2ObjectEntrySet().iterator();
		while (it.hasNext()) {
			StandEffectInstance effect = it.next().getValue();
			if (!effect.toBeRemoved()) {
				effect.onTick();
			}
			if (effect.toBeRemoved()) {
				onEffectRemoved(effect);
				it.remove();
			}
		}
	}

	@ApiStatus.Internal
	public void onStandUserDeath(LivingEntity user) {
		var it = effects.int2ObjectEntrySet().iterator();
		while (it.hasNext()) {
			StandEffectInstance effect = it.next().getValue();
			if (effect.removeOnUserDeath) {
				onEffectRemoved(effect);
				it.remove();
			}
		}
	}

	@ApiStatus.Internal
	public void onStandUserRemoved(LivingEntity user) {
		for (StandEffectInstance effect : effects.values()) {
			onEffectRemoved(effect);
		}
	}

	@ApiStatus.Internal
	public void onStandUserLogout(ServerPlayer user) {
		if (!user.server.isPublished()) return;

		var it = effects.int2ObjectEntrySet().iterator();
		while (it.hasNext()) {
			StandEffectInstance effect = it.next().getValue();
			if (effect.removeOnUserLogout) {
				onEffectRemoved(effect);
				it.remove();
			}
		}
	}

	@ApiStatus.Internal
	public void onStandChanged(LivingEntity user) {
		var it = effects.int2ObjectEntrySet().iterator();
		while (it.hasNext()) {
			StandEffectInstance effect = it.next().getValue();
			if (effect.removeOnStandChanged) {
				onEffectRemoved(effect);
				it.remove();
			}
		}
	}

	@ApiStatus.Internal
	protected void onEffectRemoved(StandEffectInstance instance) {
		instance.onStop();
		LivingEntity user = standPower.getUser();
		if (!user.level().isClientSide()) {
			PacketDistributor.sendToPlayersTrackingEntityAndSelf(user, TrStandEffectPacket.remove(instance));
		}
	}


	@ApiStatus.Internal
	public void syncWithUserOnly(ServerPlayer user) {
		effects.values().forEach(effect -> {
			effect.syncWithUserOnly(user);
		});
	}

	@ApiStatus.Internal
	public void syncWithTrackingOrUser(ServerPlayer player) {
		effects.values().forEach(effect -> {
			effect.syncWithTrackingOrUser(player);
		});
	}

	@ApiStatus.Internal
	public CompoundTag writeNBT() {
		CompoundTag nbt = new CompoundTag();
		ListTag effectsList = new ListTag();
		effects.forEach((id, effect) -> {
			if (!effect.toBeRemoved()) {
				effectsList.add(effect.toNBT());
			}
		});
		nbt.put("Effects", effectsList);
		return nbt;
	}

	@ApiStatus.Internal
	public void readNBT(CompoundTag nbt) {
		if (nbt.contains("Effects", Tag.TAG_LIST)) {
			Level level = standPower.getUser().level();
			nbt.getList("Effects", Tag.TAG_COMPOUND).forEach(effectNBT -> {
				StandEffectInstance effect = StandEffectInstance.fromNBT((CompoundTag) effectNBT, level);
				if (effect != null) {
					putEffectInstance(effect.withId(EFFECTS_COUNTER.incrementAndGet()));
				}
			});
		}
	}

}
