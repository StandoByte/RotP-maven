package com.github.standobyte.jojo.core.packet.fromclient;

import com.github.standobyte.jojo.core.PacketsRegister;
import com.github.standobyte.jojo.mc.item.DebugItem;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public class ClDebugCommandPacket implements CustomPacketPayload {
	private final String command;
	
	public ClDebugCommandPacket(String command) {
		this.command = command;
	}
	
	
	
	private static CustomPacketPayload.Type<ClDebugCommandPacket> type;
	
	public static class Handler implements PacketsRegister.PacketOGHandler<ClDebugCommandPacket> {
		
		public Handler(ResourceLocation packetId) { 
			type = new CustomPacketPayload.Type<>(packetId);
		}

		@Override
		public Type<ClDebugCommandPacket> type() {
			return type;
		}

		@Override
		public void encode(ClDebugCommandPacket packet, RegistryFriendlyByteBuf buf) {
			buf.writeUtf(packet.command);
		}

		@Override
		public ClDebugCommandPacket decode(RegistryFriendlyByteBuf buf) {
			String command = buf.readUtf();
			return new ClDebugCommandPacket(command);
		}

		@Override
		public void handle(ClDebugCommandPacket payload, IPayloadContext context) {
			Player player = context.player();
			DebugItem.handleServer(payload.command, player);
		}
		
	}
	
	@Override
	public Type<? extends CustomPacketPayload> type() {
		return type;
	}
	
}
