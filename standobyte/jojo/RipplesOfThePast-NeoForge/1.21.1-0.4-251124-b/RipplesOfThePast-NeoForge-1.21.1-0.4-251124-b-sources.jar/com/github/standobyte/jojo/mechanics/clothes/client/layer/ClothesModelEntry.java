package com.github.standobyte.jojo.mechanics.clothes.client.layer;

import javax.annotation.Nonnull;

import net.minecraft.client.model.geom.builders.LayerDefinition;

import com.github.standobyte.v1_21_4_stuff.Reminder;
import net.minecraft.resources.ResourceLocation;

public class ClothesModelEntry {
	private final ResourceLocation path;
	private final HumanoidClothesModel model;
//	private final HumanoidClothesModel adultModel;
//	private final HumanoidClothesModel babyModel;
	public final ResourceLocation texPath;
	
	public ClothesModelEntry(ResourceLocation path, LayerDefinition modelDefinition) {
		this.path = path;
		Reminder.toCreateBabyModels();
//		this.adultModel = new HumanoidClothesModel(modelDefinition.bakeRoot());
//		this.babyModel = new HumanoidClothesModel(modelDefinition.apply(HumanoidModel.BABY_TRANSFORMER).bakeRoot());
		this.model = new HumanoidClothesModel(modelDefinition.bakeRoot());
		this.texPath = path.withPath(p -> "textures/clothes/" + p + ".png");
	}
	
	@Nonnull
	public HumanoidClothesModel getModel(/*LivingEntityRenderState renderState*/) {
//		return renderState.isBaby ? babyModel : adultModel;
		return model;
	}
}