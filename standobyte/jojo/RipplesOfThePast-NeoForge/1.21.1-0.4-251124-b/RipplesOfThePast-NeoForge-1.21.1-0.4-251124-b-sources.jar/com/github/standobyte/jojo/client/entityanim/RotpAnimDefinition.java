package com.github.standobyte.jojo.client.entityanim;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.joml.Vector3f;

import com.github.standobyte.jojo.client.entityanim.action.AnimActionPhase;
import com.github.standobyte.jojo.client.entityanim.action.AnimInstructionTimelines;
import com.github.standobyte.jojo.client.entityanim.action.AnimObjTimeline;
import com.github.standobyte.jojo.client.entityanim.molang.AnimMolangQuery;
import com.github.standobyte.jojo.client.entityanim.molang.KeyframeQuery;
import com.github.standobyte.jojo.client.entityanim.playerbend.PlayerModelBends;
import com.github.standobyte.jojo.client.entityrender.EntityActionRenderState;
import com.github.standobyte.jojo.powersystem.entityaction.ActionPhase;
import com.github.standobyte.jojo.util.MathUtil;
import com.github.standobyte.jojo.util.java.OptionalFloat;
import com.github.standobyte.v1_21_4_stuff.OldPlayerModelJank;
import com.github.standobyte.v1_21_4_stuff.missingmethods.Model_1_21_2plus;
import com.github.standobyte.v1_21_4_stuff.missingmethods._PartPose;
import com.github.standobyte.v1_21_4_stuff.renderstate.LivingEntityRenderState;
import com.google.common.collect.Maps;

import it.unimi.dsi.fastutil.floats.Float2ObjectMap;
import net.minecraft.client.animation.AnimationChannel;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.util.Mth;

public class RotpAnimDefinition {
	public final float lengthInSeconds;
	public final OptionalFloat loopBackTo;
	protected final Map<String, List<AnimationChannel>> boneAnimations;
	protected final List<KeyframeQuery> queries;
	public final AnimInstructionTimelines instructionTimelines;
	
//	public float animTime;
	
	public RotpAnimDefinition(float lengthInSeconds, OptionalFloat loopBackTo, Map<String, List<AnimationChannel>> boneAnimations, 
			@Nullable List<KeyframeQuery> queries, AnimInstructionTimelines instructionTimelines) {
		this.lengthInSeconds = lengthInSeconds;
		this.loopBackTo = loopBackTo;
		this.boneAnimations = boneAnimations;
		this.queries = queries != null ? queries : Collections.emptyList();
		this.instructionTimelines = instructionTimelines;
	}


	public void animate(Model model, LivingEntityRenderState renderState, float seconds, float animSpeed) {
		Model_1_21_2plus _model = (Model_1_21_2plus) model;
		HiddenModelParts _withHidden = model instanceof HiddenModelParts __ ? __ : null;
		if (_withHidden != null) _withHidden.beforeAnim();
		evaluateQueries(renderState);
		for (Map.Entry<String, List<AnimationChannel>> entry : boneAnimations.entrySet()) {
			_model.jojo_ripples$getAnyDescendantWithName(entry.getKey()).ifPresent(modelPart -> {
				if (_withHidden != null) _withHidden.onAnimate(modelPart);
				animateModelPart(this, modelPart, entry.getValue(), seconds, animSpeed);
			});
		}
	}

	public void animateVanillaPlayer(HumanoidModel<?> humanoidModel, LivingEntityRenderState renderState, float seconds, float animSpeed) {
		evaluateQueries(renderState);
		for (Map.Entry<String, List<AnimationChannel>> entry : boneAnimations.entrySet()) {
			ModelPart modelPart = PlayerModelBends.getModelPartForPlayerAnim(humanoidModel, entry.getKey());
			animateModelPart(this, modelPart, entry.getValue(), seconds, animSpeed);
		}
		OldPlayerModelJank._onAnimate(humanoidModel);
	}
	
	
	/**
	 * @return action anim time in seconds
	 */
	public float getAnimTime(EntityActionRenderState entityAction) {
		float animSeconds = 0;

		boolean appliedPhaseAnim = false;
		boolean usePhaseTime = entityAction.actionPhase != null && this.instructionTimelines.phases != null;
		if (usePhaseTime) {
			ActionPhase taskPhase = entityAction.actionPhase;

			Float2ObjectMap.Entry<AnimActionPhase> curPhase = null;
			Float2ObjectMap.Entry<AnimActionPhase> nextPhase = null;

			@Nonnull Float2ObjectMap.Entry<AnimActionPhase> iterPrevPhase = null;
			for (Float2ObjectMap.Entry<AnimActionPhase> animPhase : this.instructionTimelines.phases.getEntries()) {
				if (taskPhase.ordinal() < animPhase.getValue().phase.ordinal()) {
					curPhase = iterPrevPhase;
					nextPhase = animPhase;
					break;
				}
				iterPrevPhase = animPhase;
			}
			if (iterPrevPhase == null) {
				usePhaseTime = false;
			}
			else {
				ActionPhase lastAnimPhase = iterPrevPhase.getValue().phase;
				if (curPhase == null) {
					if (taskPhase == lastAnimPhase) {
						curPhase = iterPrevPhase;
					}
				}
				if (curPhase != null) {
					float curPhaseTime = curPhase.getFloatKey();
					float nextPhaseTime = nextPhase != null ? nextPhase.getFloatKey() : this.lengthInSeconds;
					switch (curPhase.getValue().timeAnimMode) {
						case FIT_PHASE_LENGTH -> {
							animSeconds = Mth.lerp(entityAction.phaseCompletion, curPhaseTime, nextPhaseTime);
							appliedPhaseAnim = true;
						}
						case CONSTANT_LENGTH -> {
							float phaseSecs = entityAction.phaseTime / 20f;
							animSeconds = curPhaseTime + phaseSecs;
//							if (entity != null && animSeconds >= this.animation.lengthInSeconds()) {
//								entity.onSetPoseAnimEnded();
//							}
							appliedPhaseAnim = true;
						}
						case LOOP_BACK -> {
							float loopLen = nextPhaseTime - curPhase.getValue().loopBackTo;
							float phaseSecs = entityAction.phaseTime / 20f;
							if (phaseSecs < nextPhaseTime - curPhaseTime) { // loop hasn't started yet
								animSeconds = curPhaseTime + phaseSecs;
							}
							else {
								animSeconds = curPhase.getValue().loopBackTo + (phaseSecs - (curPhase.getValue().loopBackTo - curPhaseTime)) % loopLen;
							}
							appliedPhaseAnim = true;
						}
					}
				}
				else if (taskPhase.ordinal() > lastAnimPhase.ordinal()) {
					animSeconds = this.lengthInSeconds;
					appliedPhaseAnim = true;
				}
			}
		}

		if (!appliedPhaseAnim) {
			float time = usePhaseTime ? entityAction.phaseTime : entityAction.time;
			animSeconds = getAnimTime(time);
		}
		return animSeconds;
	}
	
	/**
	 * @return anim time in seconds
	 */
	public float getAnimTime(float ticks) {
		float time = ticks / 20f;
		if (loopBackTo.isPresent()) {
			float loopBackTo = this.loopBackTo.getAsFloat();
			if (ticks > lengthInSeconds) {
				float loopLen = lengthInSeconds - loopBackTo;
				time = (time - loopBackTo) % loopLen + loopBackTo;
			}
		}
		return time;
	}
	
	
	public static void animateModelPart(RotpAnimDefinition anim, ModelPart modelPart, List<AnimationChannel> transformations, float seconds, float animSpeed) {
		if (modelPart == null || !modelPart.visible) return;
		for (AnimationChannel tf : transformations) {
			Vector3f vec = calcVec(anim, tf, seconds, animSpeed);
			setTargetValue(modelPart, vec, tf.target());
		}
	}

	protected static final Vector3f TEMP = new Vector3f();
	
	public static Vector3f calcVec(RotpAnimDefinition anim, AnimationChannel tf, float seconds, float animSpeed) {
		Keyframe[] keyframes = tf.keyframes();
		anim.lerpKeyframes(keyframes, seconds, animSpeed);
		if (tf.target() == AnimationChannel.Targets.ROTATION) {
			TEMP.mul(MathUtil.DEG_TO_RAD);
		}
		else if (tf.target() == AnimationChannel.Targets.POSITION) {
			TEMP.mul(1, -1, 1);
		}
		else if (tf.target() == AnimationChannel.Targets.SCALE) {
			TEMP.add(-1, -1, -1);
		}
		return TEMP;
	}
	
	public Vector3f lerpKeyframes(Keyframe[] keyframes, float seconds, float animSpeed) {
		int i = Math.max(0, Mth.binarySearch(0, keyframes.length, index -> seconds <= keyframes[index].timestamp()) - 1);
		int j = Math.min(keyframes.length - 1, i + 1);
		Keyframe keyframe = keyframes[i];
		Keyframe keyframe2 = keyframes[j];
		float h = seconds - keyframe.timestamp();
		float k = j != i ? Mth.clamp(h / (keyframe2.timestamp() - keyframe.timestamp()), 0.0f, 1.0f) : 0.0f;
		keyframe2.interpolation().apply(TEMP, k, keyframes, i, j, animSpeed);
		return TEMP;
	}
	
	public static void setTargetValue(ModelPart modelPart, Vector3f value, AnimationChannel.Target target) {
		resetChannel(modelPart, target);
		target.apply(modelPart, value);
	}
	
	public static void resetChannel(ModelPart modelPart, AnimationChannel.Target target) {
		PartPose initialPose = modelPart.getInitialPose();
		// this ain't an enum
		if (target == AnimationChannel.Targets.ROTATION) {
			modelPart.xRot = initialPose.xRot;
			modelPart.yRot = initialPose.yRot;
			modelPart.zRot = initialPose.zRot;
		}
		else if (target == AnimationChannel.Targets.POSITION) {
			modelPart.x = initialPose.x;
			modelPart.y = initialPose.y;
			modelPart.z = initialPose.z;
		}
		else if (target == AnimationChannel.Targets.SCALE) {
			modelPart.xScale = _PartPose.xScale(initialPose);
			modelPart.yScale = _PartPose.yScale(initialPose);
			modelPart.zScale = _PartPose.zScale(initialPose);
		}
	}
	
	
	private void evaluateQueries(LivingEntityRenderState renderState) {
		AnimMolangQuery.instance.fillContext(renderState);
		queries.forEach(KeyframeQuery::evaluate);
	}
	

	public static class TimelineKeys {
		public static final String BARRAGE = "barrage";
	}
	
	
	public static class Builder {
		protected float length;
		protected final Map<String, List<AnimationChannel>> animationByBone = Maps.newHashMap();
		protected OptionalFloat loopBackTo = OptionalFloat.empty();
		protected List<KeyframeQuery> queries = null;
		protected final AnimInstructionTimelines instructions = new AnimInstructionTimelines();
		
		public Builder(float lengthInSeconds) {
			this.length = lengthInSeconds;
		}

		public RotpAnimDefinition.Builder looping() {
			return looping(0);
		}

		public RotpAnimDefinition.Builder looping(float loopBackToSec) {
			this.loopBackTo = OptionalFloat.of(loopBackToSec);
			return this;
		}

		public RotpAnimDefinition.Builder addAnimation(String bone, AnimationChannel animationChannel) {
			this.animationByBone.computeIfAbsent(bone, p_329694_ -> new ArrayList<>()).add(animationChannel);
			return this;
		}

		public RotpAnimDefinition.Builder addExpressionQuery(KeyframeQuery query) {
			if (queries == null) queries = new ArrayList<>();
			if (!query.isNumericLiteral()) {
				queries.add(query);
			}
			return this;
		}
		
		public RotpAnimDefinition.Builder addActionPhaseKeyframe(AnimActionPhase value, float time) {
			if (instructions.phases == null) {
				instructions.phases = new AnimObjTimeline<>();
			}
			instructions.phases.add(time, value);
			return this;
		}
		
		public RotpAnimDefinition.Builder addFieldValueKeyframe(String field, String value, float time) {
			if (instructions.stringVals == null) {
				instructions.stringVals = new HashMap<>();
			}
			AnimObjTimeline<String> timeline = instructions.stringVals.computeIfAbsent(field, __ -> new AnimObjTimeline<>());
			timeline.add(time, value);
			return this;
		}
		
		public RotpAnimDefinition build() {
			instructions.onFinishedParsing();
			RotpAnimDefinition anim = new RotpAnimDefinition(length, loopBackTo, animationByBone, queries, instructions);
			return anim;
		}
	}
	
}
